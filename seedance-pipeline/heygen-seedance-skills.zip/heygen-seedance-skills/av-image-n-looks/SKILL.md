---
name: av-image-n-looks
description: "[Avatar Studio] Identity-locked avatar LOOK generation (the default look pipeline). Generates every look as frames of ONE Seedance video off the creator's twin VIDEO (identity+motion), optionally + a PHOTO LOOK as reference_image (Shots-style appearance lock), with per-scene text prompts driving wardrobe/setting. Modes: scenes / angles / photo-only. Identity gate (ArcFace) + Gemini visual gate (bald/garbled-text/facial-hair) + re-roll loop with attempt logging. The look-stage primitive behind /av-vertical-video."
---

# image_n — identity-locked look generation (DEFAULT look pipeline)

**Type:** look-generation method + reusable module. **This is the default way to generate avatar looks for any bucket skill** — it replaces independent Nano Banana stills.

**What it is:** generate every look for a creator as **frames of one identity-locked Seedance video** (conditioned on a reference *video* of the person), instead of independent text-to-image stills. Modeled on HeyGen's "Image-N" (`resource.heygen.ai/niknolte/image-n-final-v14`): upload a short video of yourself → describe your sets → get back identity-locked frames.

## Why this is the default (validated 2026-05-26)

Head-to-head on one identity across 5 skill contexts, ArcFace cosine vs the reference:

| Look | Nano Banana stills | **Image-N (video frames)** |
|---|---|---|
| Listing Marketer | 0.756 | **0.860** |
| Brand Promo | 0.743 | **0.884** |
| Daily Science | 0.748 | **0.875** |
| Market Update | 0.753 | **0.887** |
| Form Check | 0.716 | **0.870** |

Image-N is **~+0.13 ArcFace** more identity-consistent on every look. Temporal lock (all frames from one clip) >> independent stills. Eval: `heygenverse.com/a/47cb7592-1560-46aa-95a0-ddb594f09fa0`.

## Pipeline

1. **Identity source = a reference VIDEO** of the person (a HeyGen digital-twin preview clip, or a recorded ~10s front/left/right clip). Must pass Seedance gates: ≥409,600 px, aspect [0.4–2.5], 1.8–15.2s.
2. **Register the video** as an ARK asset (`AssetType: Video`) — real-person direct URLs fail the privacy gate.
3. **Multi-scene Seedance gen**: one prompt describing N scenes, each a skill-look context (e.g. "Scene 1: a real-estate agent in a luxury living room, navy blazer…"), `role: reference_video`, `ratio 9:16`, `resolution 720p`, `duration = 1s/scene` (validated: ~5s for 5 scenes — identical identity + quality to 2.4s/scene at ~2.4x lower cost), `generate_audio: false`.
4. **Extract one frame per scene** (scene midpoints).
5. **ArcFace-score** each frame vs the reference image (InsightFace `buffalo_l`); keep the best / filter weak ones. For multiple tries, generate the video 2–3× and keep the highest-scoring frame set.

Implementation: `common/image_n.py` (`generate_scene_video`, `extract_scene_frames`, `arcface_score`). Run scoring under Python 3.11 via `uv` (onnxruntime has no 3.14 wheels).

## Prompt rules (keep SIMPLE — see [[look-gen-facial-hair-no-text]])

- Face-focused only: *"keep their exact face and identity in every shot."* Do **not** add clean-shaven / no-text clauses inline — they regress quality/consistency.
- Control facial hair + stray text **post-generation** (detect & filter candidates) rather than in the prompt.
- If a bucket template needs a real brand logo, pass it as an additional reference image (NB2/Seedance accept multiple references) rather than letting it hallucinate.

## How it slots into video creation

This is **step 0 of the look stage** for every bucket skill:

```
Image-N (look frames, identity-locked)  →  pick the skill's look frame
   →  HeyGen Photo Avatar from that frame  →  create_video_agent (avatarId = look)
   →  [+ optional seedance_hook cold-open]  →  bucket's base composition
```

So `re_listing_marketer`, the H&W skills, etc. all source their avatar look from Image-N frames instead of one-off stills. The look frame then becomes the Photo Avatar / `avatarId` used in the render (and, for cold-opens, the `last_frame` the seedance_hook lands on).

**Voice — REQUIRED:** an attached Image-N photo look comes back with `default_voice_id: null`. If you render without specifying a voice, Video Agent uses a **generic voice, not the creator's**. Always pass the creator's cloned `voiceId` on `create_video_agent` / `create_video_from_avatar` (Adam's chosen clone is **`Adam_2025` = `a8452146053043668c9ab1ba5a27650b`**, set 2026-05-27). The spoken audio is Video Agent TTS, *not* Seedance — Seedance frames/hooks are silent (`generate_audio:false`).

## Inputs

| Input | Source | Required |
|---|---|---|
| `reference_video` | creator's digital-twin clip or a recorded 10s video | ✅ |
| `reference_image` | one clear frame of the same person (for ArcFace scoring) | ✅ |
| `scenes[]` | per-skill look contexts (wardrobe + setting + framing) | ✅ |

## Performance — reuse ARK assets (don't re-ingest)
The slow part is **ARK asset registration**, not generation: Ark fetches + transcodes + content-moderates before `Status=Active` (30s–6min+, queue-bound). An `Active` `asset_id` is reusable indefinitely + across runs, so the identity `reference_video` (e.g. `adam_twin.mp4`) should be ingested **once ever**. `register_video_asset` now delegates to the persistent cache `common/ark_cache.py` (`get_or_register`, cache file `demo/.ark_asset_cache.json`) — reuses the cached asset after one fast `GetAsset`. Caveat: keys on URL; use SHA-pinned/immutable URLs (mutable `@main` content changes won't refresh the cached asset).

## Photo look (`reference_image`) — Shots-style appearance lock
Seedance accepts `reference_video` (identity/motion) **+** `reference_image` (a chosen photo look) together. `generate_scene_video(..., look_image_url=, look_image_role="reference_image")`.
- **Role rule (verified 2026-06-03):** the photo MUST be `role="reference_image"`. `first_frame`/`last_frame` anchors are rejected by ARK when a `reference_video` is present (`first/last frame content cannot be mixed with reference media content`).
- **Prompt-vs-photo dominance:** strong scene prompt → prompt drives wardrobe/scene, photo biases grooming/appearance; neutral prompt → photo drives the whole look (Shots-style).
- **Baldness fix:** formal-wardrobe prompts silently shave the head and ArcFace doesn't catch it. Passing a hair-present photo as `reference_image` restores hair (validated 2026-06-03: bald RE/Legal/HW/Edu set → full hair, mean ArcFace 0.831→0.883). The gate that catches baldness is the VISUAL gate, never ArcFace.
- Also usable as a background/property env-match (pass the listing photo). See [[reference_seedance_2_pipeline]].

### Anchor dominance — when to attach the photo (validated 2026-06-04, Eval v2)
Scaled eval (4 identities × 18 gens, 90 frames; Adam raw uploads + Diana/Marcus/Jessica public twins with controlled degradation) — [Eval v2](https://www.heygenverse.com/a/4bd36fee-7b7d-453a-9e62-d241840fe8ed), [Eval v1 pilot](https://www.heygenverse.com/a/58e29f04-9e02-46ef-b77b-acbdea44ae77):
- **The photo anchor DOMINATES.** With a `reference_image` attached, output identity converges to the PHOTO: measured ArcFace ≈ the anchor's own similarity to ground truth (±0.05), **regardless of video quality**. The photo replaces the video as the appearance source; the video supplies motion only.
- **Attach the photo CONDITIONALLY, never by default.** It fully rescues a weak capture (replicated 3/3 public chars: degraded 0.71–0.75 → 0.79–0.82, at/above the clean baseline) but **drags down a good video** (control: clean 4k 0.871 → +photo 0.720, −0.15). Rule: attach when photo quality > video quality (or user opts in); skip when the reference video is already clean.
- **Photo selection is the quality dial.** Output ≈ the photo, so the photo sets both floor and ceiling. Use the person's best recent REAL photo; reject stylized/AI-generated/outdated ones (a generated "suit" look as anchor rescued 4× worse than a plain selfie: +0.03 vs +0.12).
- **Framing is fixed by the scene PROMPT, not the photo** — even degraded-video-only outputs come back as well-composed portraits. The photo's contribution is identity + grooming.
- **Scoring hygiene:** never use the anchor photo as the ArcFace reference (circular — inflated the v1 pilot's lifts to +0.24). Score against an independent frame/photo, and calibrate by also scoring the anchor itself against that reference.
- **The video is still additive (Eval v3, 2026-06-04):** photo-only vs video+photo with the same photo — a good video adds **+0.05–0.07**, a bad video adds ~0 to +0.04 and never hurts vs photo-only. Output = photo-weighted blend (~¾ photo / ¼ video). So: if a photo is attached, KEEP the video in the call; photo-only is the floor (0.66–0.76, tracks photo quality) for users with no video. Ranking: good video alone > good video + good photo > bad video + good photo > photo alone. [Eval v3](https://www.heygenverse.com/a/d4d13470-7a38-4f34-a38d-004e3c978417)

## Visual gate + re-roll counter
`gemini_visual_gate(frame)` (Gemini 2.5 Pro) flags bald / garbled-text / wrong-facial-hair — the defects ArcFace misses. `generate_look_with_reroll(...)` loops generate→identity-gate(ArcFace≥0.55)→visual-gate→keep/re-roll, capped at `max_attempts`, and appends `{slug,attempts,passed,attempt_log}` to `reroll_log.json`. `reroll_summary()` aggregates per-look attempts + mean/max + clean-pass rate. (Re-roll counts only exist for runs that use this loop; the original gallery's were never logged.)

## HeyGenverse skill
Published as `/av-image-n-looks` (id `eda231ae-6f65-45b1-ba66-7fb982bea73b`), listed in the `/av-studio` hub. Reference app (inputs→outputs, photo-look run): heygenverse.com/a/b3c2db11-d2c1-4b13-854d-385552b60602.

## Modes (one pipeline, three shapes)

| Mode | Call | Identity from | Each "scene" is… |
|---|---|---|---|
| **scenes** (default) | `generate_scene_video` / `generate_look_pack(mode="scenes")` | reference **video** | a different look context (wardrobe + setting) |
| **angles** | `generate_angle_views` / `generate_look_pack(mode="angles")` | video **or** photo | the SAME look from a different **camera angle** |
| **photo-only** | any of the above with `reference_video_url=None` + `look_image_url` | reference **image** | (for virtual characters — no video exists) |

`generate_look_pack(...)` is the unified entry: generate → extract one frame per item → ArcFace-score, returns `{frames, arcface, mean_arcface, identity_source}`.

### Angle mode — one look → 6 angles (validated 2026-06-03)
Photo look (drives wardrobe/setting via `reference_image`) + identity video → same look from `DEFAULT_ANGLES` = Straight On · Close Up · Left 45° · Right 45° · Full Body · Side View. `build_angle_prompt` stays neutral about wardrobe/scene and varies ONLY the camera angle, so the photo wins the look. Live (Adam look + twin video): straight_on 0.964, left_45 0.918, right_45 0.945, full_body 0.877, side_view 0.787 (profile, expected low), **mean (frontal) 0.898**. An *extreme* close-up can fill the frame past ArcFace's detector → score `None` (identity still intact); use "head-and-shoulders close-up" to keep a detection margin.

### Photo-only mode — virtual characters, NO video reference (validated 2026-06-03)
A virtual character has only a single generated photo (no twin clip). Passing it as `reference_image` (no `reference_video`) and running the same multi-scene pack **still holds identity well**: 5-scene packs on two synthetic personas scored **0.818** (Maria Reyes) and **0.839** (Marcus Thorne) mean ArcFace vs the source photo — clearly above independent Nano Banana stills (~0.72–0.76, +~0.08) and only ~0.02–0.05 short of the real-person+video pipeline (~0.86–0.89). All frames visually coherent. **Takeaway: the video reference is not required for virtual characters** — the photo as sole anchor reproduces the quality pack. (Eval frames: `outputs/exp_photo_only/`, `outputs/exp_angles/`.)

## changelog
- v4 (2026-06-04) — **anchor-dominance findings from the scaled photo-rescue eval** (4 identities × 18 gens): output ≈ photo anchor (±0.05) regardless of video quality ⇒ attach `reference_image` conditionally (rescues weak captures, −0.15 on a clean video), photo selection = quality dial, framing comes from the prompt, never score against the anchor (circularity). Evals: v2 `4bd36fee`, v1 `58e29f04`.
- v3 (2026-06-03) — added **angle mode** (`generate_angle_views`/`build_angle_prompt`/`DEFAULT_ANGLES`) and the **photo-only path** (`reference_video_url=None`) for virtual characters, plus unified `generate_look_pack`. Photo-only validated at 0.82–0.84 ArcFace (no video needed); angles at mean 0.898. Fixed missing `import re`. `generate_scene_video` now takes optional `reference_video_url` + `prompt_override`.
- v2 (2026-06-03) — added optional photo-look (`reference_image`) = Shots-style look selection (role rule, prompt-vs-photo dominance, baldness fix); added Gemini visual gate + re-roll loop with attempt logging; published as HV skill `/av-image-n-looks`.
- v1 (2026-05-26) — extracted Image-N into the default look-gen method after it beat Nano Banana stills by ~+0.13 ArcFace across 5 skills. Supersedes independent-still look generation (`common/look_generation.py`, now fallback).
