# av-image-n-looks

[Avatar Studio] **Identity-locked avatar look generation** — the default look pipeline.
Generate every look as frames of ONE Seedance video conditioned on the creator's twin
**video** (identity + motion), optionally **+ a photo look** as `reference_image` (the
Shots-style appearance-lock path + the fix for the bald-head failure). Per-scene text
prompts drive wardrobe/setting. Three modes: **scenes** (default) / **angles** (one look →
N camera angles) / **photo-only** (virtual characters, no video). Quality = identity gate
(ArcFace) + Gemini visual gate (bald / garbled-text / facial-hair) + re-roll loop with
per-look attempt logging.

See `SKILL.md` for the full method, API shape, and validated numbers.

## Install
```bash
git clone https://github.com/adamhalper4/av-image-n-looks.git ~/.claude/skills/av-image-n-looks
```
Then invoke in Claude Code via `/av-image-n-looks` or by description match.

## Code
`common/image_n.py` (+ `seedance_hook.py`, `ark_cache.py`) is a **portable snapshot** of the
modules. The **canonical live copy** is in the bucket-skills repo
(`adamhalper4/bucket-skills-portfolio` → `common/image_n.py`), which is what `/av-vertical-video`
imports. Keep the two in sync when the pipeline changes (this repo is the durability mirror).

## Run
```bash
cd ~/heygen_video_skills && infisical run --projectId=bdf5f4fb-ec02-4726-8ccd-acabaf7fa86f \
  --env=dev --path=/heygen-server -- \
  uv run --python 3.11 --with insightface --with onnxruntime --with numpy --with pillow \
    --with httpx --with pycryptodome --with google-genai -- \
  python -m common.image_n <ref_video_url> <ref_image> <out_dir> <scenes.json>
```
Env (infisical /heygen-server dev): `VOLC_ACCESSKEY`, `VOLC_SECRETKEY`, `ARK_API_KEY`, `SEEDANCE_AES_KEY`.

## Surfaces (durability)
- **GitHub:** this repo (snapshot + canonical SKILL.md)
- **HeyGenverse skill:** `/av-image-n-looks` (in the `/av-studio` hub) + inputs→outputs ref app `b3c2db11`
- **Notion / HG master index:** row under `/av-vertical-video`
