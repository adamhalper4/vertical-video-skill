---
name: av-image-n-eval
description: "Run a controlled Image-N input-configuration eval — compare video/photo reference combos (good/bad videos × good/bad photos × photo-only) for identity quality. Encodes the full harness: cell-matrix design with controls, Seedance input gates + degradation recipe, anti-circularity ArcFace scoring + anchor calibration, Gemini visual gate, resumable driver, contact-strip visual review, and the HeyGenverse report format. Use when someone says 'eval Image-N inputs', 'does a photo rescue a bad video', 'photo-only vs video+photo', or wants to extend the v1/v2/v3 eval series to new characters/photos/conditions."
---

# av-image-n-eval — controlled evals of Image-N input configurations

**What it answers:** how do different reference inputs (video quality × photo quality × photo-only) change Image-N look quality, measured as identity (ArcFace) + visual defects (Gemini gate)?

**Prior results (don't re-derive — extend):**
- [Eval v2 — anchor dominance, 4 identities](https://www.heygenverse.com/a/4bd36fee-7b7d-453a-9e62-d241840fe8ed) (master doc, includes v3 section)
- [Eval v3 — video additivity](https://www.heygenverse.com/a/d4d13470-7a38-4f34-a38d-004e3c978417) · [Eval v1 pilot (superseded; has the exact ARK payload for eng)](https://www.heygenverse.com/a/58e29f04-9e02-46ef-b77b-acbdea44ae77)
- Findings already codified in `/av-image-n-looks` §Anchor dominance: photo anchor dominates (output ≈ anchor-sim ±0.05); photo rescues bad video but drags down a good one (−0.15); video is additive (+0.05–0.07 good / ~0 bad); framing comes from the prompt.

## Prereqs
- The vendored `common/image_n.py` in this skill dir — everything runs through it (`generate_scene_video`, `extract_scene_frames`, `arcface_score`, `gemini_visual_gate`). Run drivers from the skill root so `from common import image_n` resolves (see `INSTALL.md`). Read `/av-image-n-looks` first for pipeline semantics.
- **Creds:** Infisical `--projectId=bdf5f4fb-ec02-4726-8ccd-acabaf7fa86f --env=dev --path=/heygen-server` supplies `ARK_API_KEY`, `SEEDANCE_AES_KEY`, `VOLC_ACCESSKEY/SECRETKEY`, and `AWS_S3_ACCESS_ID/KEY` (for raw-upload recovery). `GEMINI_API_KEY` from your own key file (gate uses Gemini 2.5 **Pro** — flash-lite under-reports defects ~12×).
- **Python:** `uv run --python 3.11 --with insightface --with onnxruntime --with numpy --with pillow --with httpx --with google-genai --with pycryptodome` (onnxruntime has no 3.14 wheels; `pycryptodome` is required by `seedance_hook`).

## 1. Design the cell matrix (the part that makes it a real eval)
- A **cell** = (reference_video | None) × (reference_image | None), run once through a FIXED scene set. One Seedance gen per cell.
- **Always include controls:** a clean-video-only baseline per identity; if testing "does X matter", include the cell without X (e.g. photo-only cells when testing video contribution).
- **Fixed scene contexts across ALL cells** — use the canonical 5 (listing_marketer / brand_promo / daily_science / market_update / form_check; exact strings in the driver template below) so results compare to the v1–v3 series and the 0.86–0.89 clean baseline.
- Multiple identities >> multiple seeds of one identity. Public digital twins (`list_avatar_looks ownership=public avatarType=digital_twin`) give free extra characters: preview clip = video, frame@2s = photo anchor, frame@70% = scoring ref.
- Scope note for the report: 1 gen/cell has no variance estimate — differences under ~±0.03 are noise; replicate before claiming them.

## 2. Prepare inputs (Seedance gates are strict)
- Gates: ≥409,600 px total, aspect 0.4–2.5, duration 1.8–15.2s. **Trim any longer video to ~10s** (`ffmpeg -ss 2 -t 10 -an -c:v libx264 -crf 20`). A hard side-crop breaks the aspect gate — degrade *within* gates.
- **Synthetic "bad capture" recipe** (validated): `crop=iw*0.78:ih*0.78:0:0` (off-center reframe) + scale to ≈506×900 (near the pixel floor) + `boxblur=1.2` + `-crf 38`.
- **Real raw user uploads** (NOT the AI preview clips): `instant_avatar.VIDEO_URL` → `s3://heygen-resources-prod/instant_avatar/upload/<space_id>/<hash>.webm`, region **us-east-2**, presign with the Infisical S3 creds. You can `aws s3 ls` a space's prefix directly. (APIs/Oracle only ever return the generated preview.)
- Host every input on durable HeyGenverse storage: `hv_batch_upload_assets` with `{file_name}` → presigned PUT → `https://www.heygenverse.com/s/<id>/raw`. ARK can fetch those. ARK assets cache by URL (`demo/.ark_asset_cache.json`) — reuse, don't re-ingest.

## 3. Scoring — the anti-circularity rules (v1's bug; do not skip)
- **NEVER use an anchor photo as the ArcFace scoring reference.** Outputs converge to the anchor, so anchor-as-ref grades itself (inflated v1 by ~+0.1).
- Pick ONE independent scoring reference per identity (e.g. a frame from a video that is not any cell's photo anchor; for public twins use a different timestamp than the anchor frame).
- **Calibrate first:** ArcFace-score every anchor photo against the scoring ref. That number is the predicted ceiling for its +photo cells (output ≈ anchor-sim − 0.03..0.07) — and it's how you separate "identity loss" from "converged to a different-looking photo of the same person".
- Gemini gate: `bald` and `garbled_text` are the meaningful flags; `wrong_facial_hair` is calibrated to a clean-shaven subject — re-prompt or ignore for other identities.

## 4. Run — resumable driver template
Save as `driver.py`, edit JOBS, run in background; it skips completed cells on re-run.
```python
import sys, json
from pathlib import Path
# Bundle: common/ is vendored into this skill dir. Run driver.py from the skill root
# (~/.claude/skills/av-image-n-eval) so this resolves. No heygen_video_skills repo needed.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import image_n

WK = Path("/tmp/imagen_eval_out"); WK.mkdir(parents=True, exist_ok=True)
SCENES = [
 ("listing_marketer", "a real estate agent in a bright modern luxury living room, navy blazer over an open-collar shirt, warm daylight, eye-level framing, looking at camera"),
 ("brand_promo",      "a confident professional in a branded studio set with a soft key light, tailored dark suit, eye-level framing, looking at camera"),
 ("daily_science",    "a science-minded fitness presenter in a home-gym corner, fitted dark technical polo, morning light, eye-level framing, looking at camera"),
 ("market_update",    "a market expert in a neutral office with a subtle bookshelf behind, fitted button-down shirt, even professional light, eye-level framing, looking at camera"),
 ("form_check",       "a movement coach in a clean bright gym, performance athletic top, daylight, eye-level framing, looking at camera"),
]
slugs=[s for s,_ in SCENES]; ctxs=[c for _,c in SCENES]
# (cell_id, video_url_or_None, photo_url_or_None, Path(arcface_ref))  — edit me
JOBS = []
results = {}; rp = WK/"results.json"
if rp.exists(): results = json.loads(rp.read_text())
for cell, vid, photo, ref in JOBS:
    if "rows" in results.get(cell, {}): print(f"{cell}: cached"); continue
    d = WK/cell; d.mkdir(exist_ok=True); mp4 = d/"scenes.mp4"
    try:
        image_n.generate_scene_video(vid, ctxs, mp4, aspect_ratio="9:16",
            look_image_url=photo, look_image_role="reference_image", duration_s=max(5,len(ctxs)))
    except Exception as e:
        results[cell]={"error":str(e)}; rp.write_text(json.dumps(results,indent=2)); continue
    frames = image_n.extract_scene_frames(mp4, len(ctxs), d, slugs)
    scores = image_n.arcface_score(frames, ref)
    rows=[{"slug":s,"frame":str(f),"arcface":scores.get(f.stem),
           "gate":(lambda fr: (lambda g: g)(image_n.gemini_visual_gate(fr)))(f)} for s,f in zip(slugs,frames)]
    arcs=[r["arcface"] for r in rows if r["arcface"] is not None]
    results[cell]={"video":vid,"photo":photo,"rows":rows,
                   "mean_arcface":round(sum(arcs)/len(arcs),4) if arcs else None}
    rp.write_text(json.dumps(results,indent=2))
print("DONE")
```
```bash
cd ~/.claude/skills/av-image-n-eval && infisical run --projectId=bdf5f4fb-ec02-4726-8ccd-acabaf7fa86f --env=dev --path=/heygen-server -- \
uv run --python 3.11 --with insightface --with onnxruntime --with numpy --with pillow --with httpx --with google-genai --with pycryptodome -- python driver.py
```
Run it in the background; ~13 fresh ARK ingests + 18 gens ≈ 60–120 min (cached assets make reruns much faster). macOS `/bin/bash` is 3.2 — no `declare -A`.

## 5. Analyze + report
- Table: per-cell mean ArcFace; deltas vs the matched control; the anchor-calibration column next to every +photo cell.
- **Visual review is mandatory** (ArcFace misses bald/garbled/framing): per cell build a contact strip `ffmpeg -i f1..f5 -filter_complex "[0][1][2][3][4]hstack=5,scale=-2:480" strip.jpg`, then actually look at them.
- Report = HeyGenverse app in the light+purple Leadership-Data-Brief style (see Eval v2 as the template): verdict boxes up top → calibration table → numbers grid → per-cell strips → product rules → pilot-corrections if any → collapsed Methodology with scope limits. `access_level:"anyone_with_link"`.
- Wire it in: link from the prior eval app(s), append to the Image-N Master Artifacts Index (Notion `36d449792c698180ac1dc79dd446ce6b`), and fold durable FINDINGS into `/av-image-n-looks` (+ changelog) so the generation skill stays the single source of truth.

## Gotchas (each cost us a retry)
- `pycryptodome` missing → `No module named 'Crypto'` at import.
- Public twin previews can be <6s — fine (gate floor is 1.8s) but extract ref frames at % of duration, not fixed seconds (a t=8s seek past EOF silently writes nothing).
- Bucket region us-east-2: presigning with default us-east-1 → 400.
- `/s/raw` serves via 302 redirect — that's healthy, not an error.
- HV file uploads from a remote agent: `url:` fetch or `{file_name}`→presigned-PUT only; `file_path` doesn't work remotely; base64 caps ~100KB.

## changelog
- v1 (2026-06-04) — extracted the eval harness from the v1→v2→v3 photo-rescue series (Adam + Diana/Marcus/Jessica, 26 generations total).
