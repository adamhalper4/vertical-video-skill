# Install — av-image-n-eval

Controlled eval harness for Image-N input configurations (video/photo reference combos ×
fixed scene set), with anti-circularity ArcFace scoring + Gemini visual gate + a resumable
driver. See `SKILL.md` for the full method.

## Install
Unzip into your Claude Code skills directory (alongside the sibling skills):
```
~/.claude/skills/av-image-n-eval/
```
Available as `/av-image-n-eval`, or auto-invoked on "eval image-n inputs" /
"does a photo rescue a bad video".

## Layout
```
av-image-n-eval/
├── SKILL.md            # method: cell matrix, scoring, driver template, report format
├── INSTALL.md          # this file
├── requirements.txt
└── common/             # VENDORED Seedance primitives — no external repo needed
    ├── image_n.py      # generate_scene_video, extract_scene_frames, arcface_score, gemini_visual_gate
    ├── seedance_hook.py
    └── ark_cache.py
```

> `SKILL.md` was originally written to run from the `~/heygen_video_skills` repo. In this
> bundle the `common/` package is **vendored into the skill dir**, so run the driver from
> **this skill's root** (`cd ~/.claude/skills/av-image-n-eval`) — `from common import image_n`
> resolves locally. You do **not** need the `heygen_video_skills` repo.

## Credentials
Same gate as the rest of the bundle — pull from Infisical `/heygen-server` (dev):
`ARK_API_KEY`, `VOLC_ACCESSKEY`, `VOLC_SECRETKEY`, `SEEDANCE_AES_KEY`, `GEMINI_API_KEY`.
See `../START_HERE.md` for the full table and the `infisical run` wrapper.

## Run
```bash
cd ~/.claude/skills/av-image-n-eval
# edit JOBS in your driver.py (template is in SKILL.md §4), then:
infisical run --projectId=bdf5f4fb-ec02-4726-8ccd-acabaf7fa86f --env=dev --path=/heygen-server -- \
  uv run --python 3.11 \
    --with insightface --with onnxruntime --with numpy --with pillow \
    --with httpx --with google-genai --with pycryptodome -- \
    python driver.py
```
The driver is resumable — it skips cells that already have results on re-run.

## Common errors
- `No module named 'Crypto'` → add `--with pycryptodome` (required by `seedance_hook`).
- `No module named 'common'` → you're not in the skill root; `cd` here first.
- onnxruntime install fails → you're on Python 3.14; pin `--python 3.11`.
