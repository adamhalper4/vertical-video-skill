"""
Image-N look generation — identity-locked look frames from a Seedance video.

The unlock (validated 2026-05-26): generating every look as an independent
Nano Banana still drifts identity (ArcFace ~0.72-0.76 vs the subject). Generating
all looks as frames of ONE Seedance video conditioned on a reference VIDEO of the
person holds identity far better (ArcFace ~0.86-0.89, +~0.13). So:

  reference_video (the person's twin clip)  ->  Seedance multi-scene generation
  (N scenes, each a skill-look context)     ->  extract 1 frame per scene
                                            ->  ArcFace-score vs reference, keep best

ENV (infisical /heygen-server dev): VOLC_ACCESSKEY, VOLC_SECRETKEY, ARK_API_KEY, SEEDANCE_AES_KEY
Scoring needs InsightFace (run under Python 3.11 via uv — onnxruntime has no 3.14 wheels):
  uv run --python 3.11 --with insightface --with onnxruntime --with numpy --with pillow \
    --with google-genai -- python -m common.image_n ...
"""
from __future__ import annotations
import os, re, time, json, subprocess
from pathlib import Path
import httpx
from common.seedance_hook import _volc_call, compute_safety_identifier, ARK_ENDPOINT, SEEDANCE_MODEL


def register_video_asset(url: str, ak: str, sk: str, timeout_s: int = 240) -> str:
    """Register a reference VIDEO as an ARK asset (real-person video fails direct-URL privacy gate).

    Reuses a cached Active asset for this URL when possible (skips the slow ingest).
    """
    try:
        from common.ark_cache import get_or_register
        return get_or_register(url, "Video", ak, sk)
    except Exception:
        pass  # fall back to fresh registration below
    gr = _volc_call("CreateAssetGroup",
                    {"Name": f"imagen-{int(time.time())}", "Description": "Image-N reference video"}, ak, sk)
    gid = gr["Result"]["Id"]
    r = _volc_call("CreateAsset",
                   {"GroupId": gid, "Source": "URL", "URL": url, "AssetType": "Video"}, ak, sk)
    aid = r["Result"]["Id"]
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        time.sleep(4)
        st = _volc_call("GetAsset", {"Id": aid}, ak, sk).get("Result", {}).get("Status")
        if st == "Active":
            return aid
        if st in ("Failed", "Rejected"):
            raise RuntimeError(f"video asset {aid} failed: {st}")
    raise TimeoutError(f"video asset {aid} not Active in {timeout_s}s")


def build_scene_prompt(scenes: list[str], aspect_ratio: str = "9:16",
                       identity_source: str = "video") -> str:
    """scenes = list of look-context strings. Returns a multi-scene Seedance prompt.

    `aspect_ratio` ∈ {"9:16", "16:9"} drives both the orientation clause in the natural-language
    prompt AND the framing ("medium portrait" vs "medium landscape framing"). Must match the
    `ratio` passed to the Seedance API.

    `identity_source` ∈ {"video", "image"} — which reference the prompt tells Seedance to lock
    identity from. "video" (default) = the classic Image-N reference_video path. "image" = the
    photo-only path (a virtual character with no video reference); see generate_scene_video.

    Prompt stays SIMPLE and face-focused (clean-shaven / no-text clauses regress quality —
    we filter facial-hair/text candidates post-gen instead). See [[look-gen-facial-hair-no-text]].
    """
    lines = "  ".join(f"Scene {i+1}: {s}." for i, s in enumerate(scenes))
    if aspect_ratio == "16:9":
        orientation_clause = "horizontal 16:9 landscape framing"
        framing = "medium landscape shot with subject centered, room to either side for scene context"
    else:
        orientation_clause = "vertical 9:16"
        framing = "medium portrait"
    ref = "reference image" if identity_source == "image" else "reference video"
    return (
        f"Using the person from the {ref} — keep their exact face and identity in every "
        f"shot — generate a sequence of {len(scenes)} distinct professional scenes, each a clean "
        f"{framing} of the same person looking at camera, holding still for a beat before a "
        f"hard cut to the next: {lines} "
        f"Photorealistic, {orientation_clause}, professional lighting, distinct hard cuts between scenes."
    )


# ---------------------------------------------------------------------------
# Angle mode: ONE look -> many camera angles (instead of many scenes)
# ---------------------------------------------------------------------------
# Same Image-N pipeline (identity-locked Seedance video frames), but every "scene" is the SAME
# look (wardrobe + setting) shot from a different camera angle. The look comes from the photo
# `reference_image`; the text varies ONLY the angle, so the prompt stays deliberately neutral
# about wardrobe/scene (let the photo win those).

DEFAULT_ANGLES = [
    {"slug": "straight_on", "label": "Straight On",
     "prompt": "a straight-on front view at eye level, the person facing the camera directly, head-and-shoulders framing"},
    {"slug": "close_up", "label": "Close Up",
     "prompt": "a tight close-up of the face at eye level, the face filling most of the frame, facing the camera"},
    {"slug": "left_45", "label": "Left 45°",
     "prompt": "a three-quarter view with the camera 45 degrees to the person's left, head turned slightly toward camera, head-and-shoulders framing"},
    {"slug": "right_45", "label": "Right 45°",
     "prompt": "a three-quarter view with the camera 45 degrees to the person's right, head turned slightly toward camera, head-and-shoulders framing"},
    {"slug": "full_body", "label": "Full Body",
     "prompt": "a full-body wide shot showing the entire person from head to toe, standing and facing the camera"},
    {"slug": "side_view", "label": "Side View",
     "prompt": "a full profile side view with the camera at 90 degrees to the side of the face, head-and-shoulders framing"},
]


def build_angle_prompt(angles: list[dict], aspect_ratio: str = "9:16",
                       identity_source: str = "video") -> str:
    """Multi-shot Seedance prompt that holds ONE look constant and varies only the camera angle.

    Unlike build_scene_prompt (which describes N *different* look contexts), every shot here is the
    SAME person in the SAME outfit and SAME setting — only the camera angle changes. The look
    (wardrobe + environment) is meant to come from the photo `reference_image`, so the text stays
    deliberately neutral about wardrobe/scene and only names the angle. See generate_angle_views.
    """
    lines = "  ".join(f"Shot {i+1}: {a['prompt']}." for i, a in enumerate(angles))
    orientation = "horizontal 16:9 landscape" if aspect_ratio == "16:9" else "vertical 9:16 portrait"
    ref = "reference image" if identity_source == "image" else "reference video"
    return (
        f"Using the person from the {ref} — keep their exact face and identity in every shot — and "
        "matching the EXACT same outfit, hairstyle, grooming, and background setting shown in the "
        f"reference image, generate a sequence of {len(angles)} shots of the SAME person in the SAME "
        "look and SAME location, changing ONLY the camera angle and framing between shots, each held "
        f"still for a beat before a hard cut to the next: {lines} "
        f"Photorealistic, {orientation}, consistent wardrobe, lighting, and background across every "
        "shot, distinct hard cuts between shots."
    )


def generate_scene_video(reference_video_url: str | None, scenes: list[str], out_path: Path,
                         duration_s: int | None = None, username: str = "stage_h_imagen",
                         aspect_ratio: str = "9:16", look_image_url: str | None = None,
                         look_image_role: str = "reference_image",
                         prompt_override: str | None = None) -> dict:
    """Register the ref video, run a multi-scene Seedance gen, download the clip. Returns task info.

    `aspect_ratio` ∈ {"9:16", "16:9"} — drives both the Seedance `ratio` param and the natural-
    language framing clause. Use generate_scene_videos_by_canvas() to fan out mixed-orientation
    look batches in parallel.

    `reference_video_url` may be None for the **photo-only path** (a virtual character with no
    video reference) — pass `look_image_url` instead and the photo becomes the sole identity/look
    anchor. At least one of reference_video_url / look_image_url is required.

    `prompt_override` — use a fully-formed prompt instead of build_scene_prompt (e.g. the angle
    prompt from build_angle_prompt). When set, `scenes` is ignored for prompt text (still used for
    the duration default).
    """
    assert aspect_ratio in ("9:16", "16:9"), f"unsupported aspect_ratio {aspect_ratio!r}"
    if not reference_video_url and not look_image_url:
        raise ValueError("need at least one of reference_video_url / look_image_url")
    # 1s/scene is validated (2026-05-26): identical identity (~0.87 ArcFace) + clean frames
    # vs 2.4s/scene, at ~2.4x lower cost. Floor at 5s (Seedance min ~1.8s overall).
    if duration_s is None:
        duration_s = max(5, len(scenes))
    ak, sk = os.environ["VOLC_ACCESSKEY"], os.environ["VOLC_SECRETKEY"]
    ark, aes = os.environ["ARK_API_KEY"], os.environ["SEEDANCE_AES_KEY"]
    from common.seedance_hook import register_image_asset
    identity_source = "video" if reference_video_url else "image"
    text = prompt_override or build_scene_prompt(scenes, aspect_ratio=aspect_ratio,
                                                 identity_source=identity_source)
    content = [{"type": "text", "text": text}]
    vid = None
    if reference_video_url:
        vid = register_video_asset(reference_video_url, ak, sk)
        content.append({"type": "video_url", "video_url": {"url": f"asset://{vid}"},
                        "role": "reference_video"})
    # Optional photo-look conditioning (Shots-style): pass a chosen photo look so it drives
    # wardrobe/setting (and, in the photo-only path, identity too). When a video reference is
    # ALSO present, MUST use role="reference_image" — ARK rejects first_frame/last_frame anchors
    # mixed with reference_video ("first/last frame content cannot be mixed with reference media").
    # Verified 2026-06-03: reference_image + reference_video is accepted; with a neutral text
    # prompt the photo fully drives the look, with a strong text prompt the prompt wins wardrobe/
    # scene and the photo mainly biases grooming/appearance.
    if look_image_url:
        img = register_image_asset(look_image_url, ak, sk)
        content.append({"type": "image_url", "image_url": {"url": f"asset://{img}"},
                        "role": look_image_role})
    payload = {
        "model": SEEDANCE_MODEL,
        "content": content,
        "ratio": aspect_ratio, "duration": duration_s, "resolution": "720p",
        "safety_identifier": compute_safety_identifier(username, aes),
        "generate_audio": False,
    }
    r = httpx.post(ARK_ENDPOINT, headers={"Authorization": f"Bearer {ark}", "Content-Type": "application/json"},
                   content=json.dumps(payload).encode(), timeout=60)
    if r.status_code >= 400:
        raise RuntimeError(
            f"ARK {r.status_code}: {r.text}\n"
            f"  payload-preview: model={payload['model']} ratio={payload['ratio']} "
            f"duration={payload['duration']} content_parts={len(payload['content'])}"
        )
    tid = r.json()["id"]
    deadline = time.time() + 900
    while time.time() < deadline:
        time.sleep(8)
        d = httpx.get(f"{ARK_ENDPOINT}/{tid}", headers={"Authorization": f"Bearer {ark}"}, timeout=30).json()
        st = d.get("status")
        if st == "succeeded":
            c = d.get("content")
            url = c.get("video_url") if isinstance(c, dict) else c[0]["video_url"]["url"]
            out_path.write_bytes(httpx.get(url, timeout=180).content)
            return {"task": tid, "asset": vid, "video": str(out_path)}
        if st in ("failed", "cancelled"):
            raise RuntimeError(f"Image-N gen {st}: {d}")
    raise TimeoutError(f"Image-N task {tid} timeout")


def generate_angle_views(reference_video_url: str | None, look_image_url: str, out_path: Path,
                         angles: list[dict] | None = None, duration_s: int | None = None,
                         username: str = "imagen_angles", aspect_ratio: str = "9:16") -> dict:
    """Multi-ANGLE Image-N: given ONE photo look (+ optionally an identity reference video), render
    the SAME look from several camera angles (default DEFAULT_ANGLES: straight-on, close-up,
    left/right 45°, full body, side view) as scenes of one identity-locked Seedance clip.

    `look_image_url` is required (it drives wardrobe/setting and, when there's no video, identity).
    `reference_video_url` is optional — pass it to also lock identity from a real-person video.
    Extract one frame per angle with extract_scene_frames(out_path, len(angles), names=[slugs]).
    """
    angles = angles or DEFAULT_ANGLES
    if duration_s is None:
        duration_s = max(5, len(angles))
    identity_source = "video" if reference_video_url else "image"
    prompt = build_angle_prompt(angles, aspect_ratio=aspect_ratio, identity_source=identity_source)
    info = generate_scene_video(
        reference_video_url, [a["prompt"] for a in angles], out_path,
        duration_s=duration_s, username=username, aspect_ratio=aspect_ratio,
        look_image_url=look_image_url, look_image_role="reference_image",
        prompt_override=prompt,
    )
    info["angles"] = [a["slug"] for a in angles]
    return info


def generate_look_pack(out_dir: Path, scenes: list[dict], *,
                       reference_video_url: str | None = None, look_image_url: str | None = None,
                       reference_image: Path | str | None = None, mode: str = "scenes",
                       aspect_ratio: str = "9:16", username: str = "imagen_pack") -> dict:
    """End-to-end Image-N pack: generate -> extract one frame per item -> ArcFace-score, all in one.

    Unifies the three pipeline shapes so the photo-only-vs-video question is a one-flag change:

      • mode="scenes"  -> scenes = [{"slug","prompt"}], build_scene_prompt (N different looks)
      • mode="angles"  -> scenes = [{"slug","prompt"}] OR None (defaults to DEFAULT_ANGLES);
                          ONE look from N camera angles (look_image_url drives the look)

    Identity source:
      • reference_video_url set            -> classic Image-N (video locks identity)
      • reference_video_url None + look    -> PHOTO-ONLY path (virtual character; image is the
                                              sole anchor). This is the no-video experiment.

    `reference_image` (local path) is what ArcFace scores against. For the photo-only path this is
    naturally a local copy of the look photo itself (self-consistency of the pack vs its source).
    Returns {info, frames:[...], arcface:{slug:score}, mean_arcface, mode, identity_source}.
    """
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    if mode == "angles":
        items = scenes or DEFAULT_ANGLES
        slugs = [a["slug"] for a in items]
        mp4 = out_dir / "pack.mp4"
        info = generate_angle_views(reference_video_url, look_image_url, mp4, items,
                                    aspect_ratio=aspect_ratio, username=username)
    else:
        items = scenes
        slugs = [s["slug"] for s in items]
        mp4 = out_dir / "pack.mp4"
        info = generate_scene_video(
            reference_video_url, [s["prompt"] for s in items], mp4,
            aspect_ratio=aspect_ratio, username=username,
            look_image_url=look_image_url, look_image_role="reference_image",
        )
    frames = extract_scene_frames(mp4, len(items), out_dir / "frames", names=slugs)
    scores = arcface_score(frames, Path(reference_image)) if reference_image else {}
    vals = [v for v in scores.values() if v is not None]
    return {
        "info": info,
        "frames": [str(f) for f in frames],
        "arcface": scores,
        "mean_arcface": round(sum(vals) / len(vals), 4) if vals else None,
        "mode": mode,
        "identity_source": "video" if reference_video_url else "image",
    }


def generate_scene_videos_by_canvas(reference_video_url: str,
                                     scenes_with_canvas: list[dict],
                                     out_dir: Path,
                                     duration_s: int | None = None,
                                     username: str = "stage_h_imagen") -> list[dict]:
    """Orientation-aware multi-canvas Seedance fan-out for Image-N look generation.

    `scenes_with_canvas` = [{"prompt": str, "slug": str, "canvas": "portrait"|"landscape"}, ...]

    Splits scenes into per-canvas batches, dispatches one Seedance multi-scene job per batch
    (sequentially — Seedance has per-account rate limits on concurrent gen jobs), downloads each
    output clip, then returns a unified [{"slug","canvas","video_path","scene_idx_in_batch",
    "batch_total"}] list ordered to match the input.

    Use this instead of generate_scene_video when a single skill-look batch mixes orientations
    (e.g. some bucket-skills render 9:16 and others render 16:9 in the same vertical).

    Returns: list of dicts (one per input scene, in original order) with:
      - slug: scene slug
      - canvas: "portrait" | "landscape"
      - video_path: path to the batch's downloaded mp4 (shared across scenes in same batch)
      - scene_idx_in_batch: 0-based index of this scene WITHIN its canvas batch (use for
        passing to extract_scene_frames as the right `n_scenes` ordering).
      - batch_total: number of scenes in that batch
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    portrait_scenes = [(i, s) for i, s in enumerate(scenes_with_canvas) if s["canvas"] == "portrait"]
    landscape_scenes = [(i, s) for i, s in enumerate(scenes_with_canvas) if s["canvas"] == "landscape"]

    results: list[dict | None] = [None] * len(scenes_with_canvas)

    for canvas, ratio, batch in (
        ("portrait", "9:16", portrait_scenes),
        ("landscape", "16:9", landscape_scenes),
    ):
        if not batch:
            continue
        prompts = [s["prompt"] for _, s in batch]
        video_path = out_dir / f"stills_{canvas}.mp4"
        print(f"[image_n] dispatching {canvas} ({ratio}) Seedance job — {len(prompts)} scenes")
        generate_scene_video(
            reference_video_url, prompts, video_path,
            duration_s=duration_s, username=username, aspect_ratio=ratio,
        )
        for batch_idx, (orig_idx, s) in enumerate(batch):
            results[orig_idx] = {
                "slug": s["slug"],
                "canvas": canvas,
                "video_path": str(video_path),
                "scene_idx_in_batch": batch_idx,
                "batch_total": len(batch),
            }
    return results


def _video_duration(video_path: Path) -> float:
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                          "-of", "default=nw=1:nk=1", str(video_path)]).decode().strip())


def detect_scene_cuts(video_path: Path, threshold: float = 0.3) -> list[float]:
    """Return scene-cut start timestamps (seconds) via ffmpeg's scene-change score.

    These are the times where a NEW scene begins (after a hard cut). Used to align frame
    extraction to real scene boundaries instead of assuming equal segment lengths — Seedance
    scene durations are uneven, so dur/n midpoints mis-sample (double-grab one scene, skip
    another). Empirically validated 2026-05-27 on a 5-scene Image-N clip.
    """
    out = subprocess.run(
        ["ffmpeg", "-hide_banner", "-i", str(video_path),
         "-filter:v", f"select='gt(scene,{threshold})',showinfo", "-f", "null", "-"],
        capture_output=True, text=True,
    ).stderr
    cuts = []
    for line in out.splitlines():
        if "showinfo" in line and "pts_time:" in line:
            try:
                cuts.append(float(line.split("pts_time:")[1].split()[0]))
            except (IndexError, ValueError):
                pass
    return sorted(cuts)


def extract_scene_frames(video_path: Path, n_scenes: int, out_dir: Path,
                         names: list[str] | None = None, scene_threshold: float = 0.3) -> list[Path]:
    """Extract one representative frame per scene.

    Prefers REAL scene-cut detection (detect_scene_cuts): builds segment boundaries from the
    detected cuts (+ t=0) and samples each segment's midpoint. Falls back to equal dur/n
    midpoints only if detection doesn't yield exactly n_scenes-1 cuts (n_scenes segments).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    dur = _video_duration(video_path)

    cuts = detect_scene_cuts(video_path, scene_threshold)
    # boundaries = [0, cut1, cut2, ..., dur]; expect exactly n_scenes segments
    bounds = [0.0] + [c for c in cuts if 0.05 < c < dur - 0.05] + [dur]
    if len(bounds) - 1 == n_scenes:
        midpoints = [(bounds[i] + bounds[i + 1]) / 2 for i in range(n_scenes)]
    else:
        # detection disagreed with expected scene count — fall back to equal segments
        seg = dur / n_scenes
        midpoints = [seg * i + seg / 2 for i in range(n_scenes)]

    paths = []
    for i, t in enumerate(midpoints):
        name = (names[i] if names and i < len(names) else f"scene{i+1}") + ".jpg"
        p = out_dir / name
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{t:.2f}",
                        "-i", str(video_path), "-frames:v", "1", str(p)], check=True)
        paths.append(p)
    return paths


# ArcFace scoring (import lazily — only available under the uv 3.11 env)
def arcface_score(frame_paths: list[Path], reference_image: Path) -> dict[str, float]:
    import numpy as np
    from PIL import Image
    from insightface.app import FaceAnalysis
    fa = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"]); fa.prepare(ctx_id=-1, det_size=(640, 640))
    def emb(p):
        img = np.array(Image.open(p).convert("RGB"))[:, :, ::-1]
        f = fa.get(img)
        if not f: return None
        f.sort(key=lambda x: (x.bbox[2]-x.bbox[0])*(x.bbox[3]-x.bbox[1]), reverse=True)
        return f[0].normed_embedding
    ref = emb(reference_image)
    out = {}
    for p in frame_paths:
        e = emb(p)
        out[p.stem] = round(float(np.dot(ref, e)), 4) if e is not None else None
    return out


# ---------------------------------------------------------------------------
# Visual gate + re-roll loop (with per-look attempt counter)
# ---------------------------------------------------------------------------
# ArcFace only scores IDENTITY — it does NOT penalise a shaved/bald head, garbled
# on-screen text/signage, or wrong facial hair (a buzzed roll still scores ~0.82
# and passes). So a clean look needs a second, VISUAL gate. We use Gemini Pro
# (flash-lite under-reports defects ~12x — see [[gemini_flash_lite_visual_audit_too_weak]]).

VISUAL_GATE_MODEL = "gemini-2.5-pro"

def gemini_visual_gate(frame_path: Path, *, gemini_key: str | None = None,
                       model: str = VISUAL_GATE_MODEL) -> dict:
    """Return {"ok": bool, "bald": bool, "garbled_text": bool, "wrong_facial_hair": bool,
    "reason": str} for one look frame. ok=False ⇒ re-roll. Defects ArcFace can't see."""
    from google import genai
    from google.genai import types
    key = gemini_key or os.environ.get("GEMINI_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY not set (visual gate)")
    client = genai.Client(api_key=key)
    img = frame_path.read_bytes()
    prompt = (
        "You are a strict QC reviewer for a digital-avatar look. Inspect this single portrait frame "
        "and report defects ONLY. Return STRICT JSON with keys: "
        "bald (true if the head is shaved/buzzed/balding or hair is unnaturally missing — the subject "
        "normally has a full head of thick dark hair), "
        "garbled_text (true if there is any unreadable/misspelled/warped on-screen text, signage, or "
        "logo lettering anywhere in the frame), "
        "wrong_facial_hair (true if there is a beard/stubble/moustache — the subject is clean-shaven), "
        "reason (one short sentence). "
        "ok = true ONLY if bald, garbled_text, and wrong_facial_hair are ALL false. "
        "Respond with JSON only, no prose."
    )
    resp = client.models.generate_content(
        model=model,
        contents=[types.Part.from_bytes(data=img, mime_type="image/jpeg"), prompt],
    )
    txt = (resp.text or "").strip()
    m = re.search(r"\{.*\}", txt, re.S)
    if not m:
        return {"ok": False, "bald": False, "garbled_text": False, "wrong_facial_hair": False,
                "reason": f"unparseable gate response: {txt[:80]}"}
    v = json.loads(m.group(0))
    v["ok"] = not (v.get("bald") or v.get("garbled_text") or v.get("wrong_facial_hair"))
    return v


def generate_look_with_reroll(
    reference_video_url: str, scene_prompt: str, slug: str, out_dir: Path,
    reference_image: Path, *, max_attempts: int = 4, arcface_min: float = 0.55,
    visual_gate: bool = True, aspect_ratio: str = "9:16", username: str = "stage_h_imagen",
    reroll_log_path: Path | None = None,
) -> dict:
    """Generate ONE look, re-rolling until it passes the identity gate (ArcFace >= arcface_min)
    AND the visual gate (no bald / garbled-text / wrong-facial-hair), capped at max_attempts.

    Returns {slug, look_path, arcface, attempts, passed, attempt_log:[{attempt,arcface,visual,kept}]}.
    Appends the same record to reroll_log_path (default out_dir/reroll_log.json) so re-roll counts
    are tracked per look — the metric that was never recorded for the original gallery.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    reroll_log_path = reroll_log_path or (out_dir / "reroll_log.json")
    attempt_log: list[dict] = []
    best = {"arcface": -1.0, "look_path": None, "visual": None}

    for attempt in range(1, max_attempts + 1):
        mp4 = out_dir / f"{slug}__try{attempt}.mp4"
        generate_scene_video(reference_video_url, [scene_prompt], mp4,
                             duration_s=5, username=username, aspect_ratio=aspect_ratio)
        frame = extract_scene_frames(mp4, 1, out_dir / "frames", [f"{slug}__try{attempt}"])[0]
        arc = arcface_score([frame], reference_image).get(frame.stem)
        vis = gemini_visual_gate(frame) if visual_gate else {"ok": True, "reason": "visual gate off"}
        id_ok = arc is not None and arc >= arcface_min
        kept = bool(id_ok and vis.get("ok"))
        attempt_log.append({"attempt": attempt, "arcface": arc, "visual": vis, "kept": kept,
                            "frame": str(frame)})
        print(f"[reroll] {slug} try{attempt}: arcface={arc} visual_ok={vis.get('ok')} "
              f"({vis.get('reason','')})", flush=True)
        # track best-by-identity as a fallback if we never get a clean pass
        if arc is not None and arc > best["arcface"]:
            best = {"arcface": arc, "look_path": str(frame), "visual": vis}
        if kept:
            result = {"slug": slug, "look_path": str(frame), "arcface": arc, "attempts": attempt,
                      "passed": True, "attempt_log": attempt_log}
            _append_reroll_log(reroll_log_path, result)
            return result

    # exhausted attempts — return best-by-identity but flag not-passed (needs manual review)
    result = {"slug": slug, "look_path": best["look_path"], "arcface": best["arcface"],
              "attempts": max_attempts, "passed": False, "attempt_log": attempt_log,
              "note": "max attempts hit without a clean pass — best-identity frame returned, review manually"}
    _append_reroll_log(reroll_log_path, result)
    return result


def _append_reroll_log(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    log = json.loads(path.read_text()) if path.exists() else []
    log.append({k: record[k] for k in ("slug", "arcface", "attempts", "passed") if k in record}
               | {"attempt_log": record.get("attempt_log")})
    path.write_text(json.dumps(log, indent=2))


def reroll_summary(reroll_log_path: Path) -> dict:
    """Aggregate a reroll_log.json: per-look attempts + fleet stats (mean/max attempts, pass-rate)."""
    log = json.loads(Path(reroll_log_path).read_text())
    per = {r["slug"]: {"attempts": r["attempts"], "passed": r["passed"]} for r in log}
    att = [r["attempts"] for r in log]
    return {
        "per_look": per,
        "looks": len(log),
        "mean_attempts": round(sum(att) / len(att), 2) if att else None,
        "max_attempts": max(att) if att else None,
        "total_generations": sum(att),
        "clean_pass_rate": round(sum(1 for r in log if r["passed"]) / len(log), 3) if log else None,
    }


if __name__ == "__main__":
    # python -m common.image_n <ref_video_url> <ref_image> <out_dir> <scenes.json>
    import sys
    ref_url, ref_img, out_dir, scenes_json = sys.argv[1:5]
    cfg = json.loads(Path(scenes_json).read_text())  # [{"skill":..,"context":..}, ...]
    od = Path(out_dir); od.mkdir(parents=True, exist_ok=True)
    info = generate_scene_video(ref_url, [c["context"] for c in cfg], od / "scenes.mp4")
    frames = extract_scene_frames(od / "scenes.mp4", len(cfg), od / "frames", [c["skill"] for c in cfg])
    scores = arcface_score(frames, Path(ref_img))
    json.dump({"info": info, "scores": scores}, open(od / "_result.json", "w"), indent=1)
    print(json.dumps(scores, indent=1))
