"""
Seedance 2.0 hook generator — image-to-video with last-frame anchoring.

Workflow per the user's request:
  1. Generate avatar look via Nano Banana Pro → PNG
  2. Register that PNG as an ARK asset (bypasses privacy detection for real-person inputs)
  3. Submit Seedance 2.0 generation with image_url role=last_frame
  4. Seedance generates a 4-6s cinematic clip whose END frame matches the look
  5. Concat seedance hook + avatar talking video → seamless transition
     (because last frame of seedance ≈ first frame of avatar render)

ENV requirements (from infisical heygen-server / dev):
  ARK_API_KEY, VOLC_ACCESSKEY, VOLC_SECRETKEY, SEEDANCE_AES_KEY

Usage:
  python3 seedance_hook.py <look_image_path_or_url> <motion_prompt>
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import hmac
import json
import os
import sys
import time
import urllib.parse
from pathlib import Path

import httpx
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes


ARK_ENDPOINT = "https://ark.ap-southeast.bytepluses.com/api/v3/contents/generations/tasks"
SEEDANCE_MODEL = "ep-20260407050955-dldjv"  # dreamina-seedance-2-0-260128
VOLC_HOST = "open.volcengineapi.com"


# ---------------------------------------------------------------------------
# Volcengine V4 signature (for ARK asset registration via universal API)
# ---------------------------------------------------------------------------

def _sign_v4(method: str, path: str, query: dict, headers: dict, body: bytes, ak: str, sk: str, service: str, region: str) -> dict:
    """Sign a Volcengine universal-API request with V4 SK auth."""
    now = dt.datetime.now(dt.timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = now.strftime("%Y%m%d")
    headers = {**headers, "Host": VOLC_HOST, "X-Date": amz_date}
    if body:
        headers["X-Content-Sha256"] = hashlib.sha256(body).hexdigest()

    # Canonical query string
    cqs = "&".join(
        f"{urllib.parse.quote(k, safe='-_.~')}={urllib.parse.quote(str(v), safe='-_.~')}"
        for k, v in sorted(query.items())
    )

    # Canonical headers (lowercase keys, sorted, trimmed values)
    signed_headers = sorted(headers.keys(), key=str.lower)
    canonical_headers = "".join(
        f"{h.lower()}:{str(headers[h]).strip()}\n" for h in signed_headers
    )
    signed_headers_str = ";".join(h.lower() for h in signed_headers)
    payload_hash = hashlib.sha256(body or b"").hexdigest()

    canonical_request = "\n".join([
        method.upper(), path, cqs, canonical_headers, signed_headers_str, payload_hash
    ])
    cr_hash = hashlib.sha256(canonical_request.encode()).hexdigest()

    credential_scope = f"{date_stamp}/{region}/{service}/request"
    string_to_sign = "\n".join(["HMAC-SHA256", amz_date, credential_scope, cr_hash])

    k_date = hmac.new(sk.encode(), date_stamp.encode(), hashlib.sha256).digest()
    k_region = hmac.new(k_date, region.encode(), hashlib.sha256).digest()
    k_service = hmac.new(k_region, service.encode(), hashlib.sha256).digest()
    k_signing = hmac.new(k_service, b"request", hashlib.sha256).digest()
    signature = hmac.new(k_signing, string_to_sign.encode(), hashlib.sha256).hexdigest()

    auth = (
        f"HMAC-SHA256 Credential={ak}/{credential_scope}, "
        f"SignedHeaders={signed_headers_str}, Signature={signature}"
    )
    return {**headers, "Authorization": auth}


def _volc_call(action: str, payload: dict, ak: str, sk: str) -> dict:
    """Invoke the Volcengine universal-API (service=ark, version=2024-01-01)."""
    body = json.dumps(payload).encode()
    query = {"Action": action, "Version": "2024-01-01"}
    base_headers = {"Content-Type": "application/json"}
    signed = _sign_v4("POST", "/", query, base_headers, body, ak, sk, "ark", "ap-southeast-1")
    qs = "&".join(f"{k}={v}" for k, v in query.items())
    url = f"https://{VOLC_HOST}/?{qs}"
    with httpx.Client(timeout=60.0) as client:
        r = client.post(url, content=body, headers=signed)
        r.raise_for_status()
        return r.json()


# ---------------------------------------------------------------------------
# Asset registration
# ---------------------------------------------------------------------------

def register_image_asset(image_url: str, ak: str, sk: str, group_id: str | None = None) -> str:
    """Register an image URL as an ARK asset. Returns the asset_id.

    Reuses a cached Active asset for this URL when possible (skips the slow
    fetch/transcode/moderation ingest). If group_id is omitted, creates a new group.
    """
    if not group_id:
        try:
            from common.ark_cache import get_or_register
            return get_or_register(image_url, "Image", ak, sk)
        except Exception:
            pass  # fall back to fresh registration below
    if not group_id:
        gr = _volc_call(
            "CreateAssetGroup",
            {"Name": f"bucket-skills-{int(time.time())}", "Description": "Stage H Seedance hook"},
            ak, sk,
        )
        group_id = gr["Result"]["Id"]

    r = _volc_call(
        "CreateAsset",
        {
            "GroupId": group_id,
            "Source": "URL",
            "URL": image_url,
            "AssetType": "Image",
        },
        ak, sk,
    )
    asset_id = r["Result"]["Id"]

    # Poll until Status=Active
    deadline = time.time() + 120
    while time.time() < deadline:
        time.sleep(2)
        info = _volc_call("GetAsset", {"Id": asset_id}, ak, sk)
        status = info.get("Result", {}).get("Status")
        if status == "Active":
            return asset_id
        if status in ("Failed", "Rejected"):
            raise RuntimeError(f"Asset registration failed: {info}")
    raise TimeoutError(f"Asset {asset_id} did not become Active within 120s")


# ---------------------------------------------------------------------------
# safety_identifier (per memory: AES-GCM of username with SEEDANCE_AES_KEY)
# ---------------------------------------------------------------------------

def compute_safety_identifier(username: str, aes_key_b64: str) -> str:
    """base64(nonce(12B) || tag(16B) || ciphertext) where ciphertext = AES-GCM(username, key)."""
    key = base64.b64decode(aes_key_b64)
    nonce = get_random_bytes(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(username.encode())
    return base64.b64encode(nonce + tag + ciphertext).decode()


# ---------------------------------------------------------------------------
# Seedance generation
# ---------------------------------------------------------------------------

def generate_seedance_hook(
    prompt: str,
    last_frame_asset_id: str,
    *,
    first_frame_asset_id: str | None = None,
    duration_s: int = 4,
    ratio: str = "9:16",
    resolution: str = "720p",
    username: str = "stage_h_bucket_skills",
) -> str:
    """Submit a Seedance 2.0 generation task anchored to end on the look.

    Seedance rejects a lone last_frame; it must be paired with a first_frame.
    Pass an establishing still as first_frame and the avatar look as last_frame —
    the clip interpolates establishing -> look and ENDS exactly on the look, so it
    concats seamlessly into the avatar talking video (whose first frame is the look).

    Returns the task_id (cgt-...).
    """
    ark_key = os.environ["ARK_API_KEY"]
    aes_key = os.environ["SEEDANCE_AES_KEY"]
    sid = compute_safety_identifier(username, aes_key)

    content = [{"type": "text", "text": prompt}]
    if first_frame_asset_id:
        content.append({
            "type": "image_url",
            "image_url": {"url": f"asset://{first_frame_asset_id}"},
            "role": "first_frame",
        })
    content.append({
        "type": "image_url",
        "image_url": {"url": f"asset://{last_frame_asset_id}"},
        "role": "last_frame",
    })
    payload = {
        "model": SEEDANCE_MODEL,
        "content": content,
        "ratio": ratio,
        "duration": duration_s,
        "resolution": resolution,
        "safety_identifier": sid,
        # B-roll only — the avatar talking video carries the voice. Generating audio
        # trips OutputAudioSensitiveContentDetected moderation, so disable it.
        "generate_audio": False,
    }
    with httpx.Client(timeout=60.0) as client:
        r = client.post(
            ARK_ENDPOINT,
            headers={"Authorization": f"Bearer {ark_key}", "Content-Type": "application/json"},
            content=json.dumps(payload).encode(),
        )
        if r.status_code >= 400:
            raise RuntimeError(
                f"ARK {r.status_code}: {r.text}\n"
                f"  payload-preview: model={payload['model']} ratio={payload['ratio']} "
                f"duration={payload['duration']} content_parts={len(payload['content'])}"
            )
        return r.json()["id"]


def poll_seedance(task_id: str, *, timeout_s: int = 600) -> dict:
    """Poll an ARK task until done. Returns the final task JSON."""
    ark_key = os.environ["ARK_API_KEY"]
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        with httpx.Client(timeout=30.0) as client:
            r = client.get(
                f"{ARK_ENDPOINT}/{task_id}",
                headers={"Authorization": f"Bearer {ark_key}"},
            )
            r.raise_for_status()
            data = r.json()
        status = data.get("status")
        if status == "succeeded":
            return data
        if status in ("failed", "cancelled"):
            raise RuntimeError(f"Seedance task {task_id} {status}: {data}")
        time.sleep(8)
    raise TimeoutError(f"Seedance task {task_id} did not complete within {timeout_s}s")


# ---------------------------------------------------------------------------
# End-to-end: image URL → asset → Seedance → MP4 URL
# ---------------------------------------------------------------------------

def make_hook_from_look(
    look_image_url: str,
    motion_prompt: str,
    *,
    duration_s: int = 4,
    ratio: str = "9:16",
) -> dict:
    """Full pipeline: register asset → generate → poll → return result.

    Result includes: task_id, asset_id, mp4_url, raw_response.
    """
    ak = os.environ["VOLC_ACCESSKEY"]
    sk = os.environ["VOLC_SECRETKEY"]
    print(f"[seedance] register asset for {look_image_url}")
    asset_id = register_image_asset(look_image_url, ak, sk)
    print(f"[seedance] asset registered: {asset_id}")
    print(f"[seedance] submitting generation (look as both first+last frame)")
    # ARK now rejects `last_frame` alone — must be paired with `first_frame`. We pass
    # the SAME look asset as both anchors: Seedance interpolates motion within the
    # look's identity/environment so first → last shares person+env (clip starts at
    # the look, the prompt directs the in-shot motion, ends back at the look).
    task_id = generate_seedance_hook(
        motion_prompt, asset_id,
        first_frame_asset_id=asset_id,
        duration_s=duration_s, ratio=ratio,
    )
    print(f"[seedance] task: {task_id}, polling …")
    result = poll_seedance(task_id)
    # Modern ARK shape: content is an object {"video_url": "<url>"} (a string).
    # Older shape was a list with .url nesting. Handle both.
    content = result.get("content")
    mp4_url = None
    if isinstance(content, dict):
        v = content.get("video_url")
        mp4_url = v if isinstance(v, str) else (v.get("url") if isinstance(v, dict) else None)
    elif isinstance(content, list):
        for c in content:
            v = c.get("video_url") if isinstance(c, dict) else None
            if isinstance(v, str):
                mp4_url = v; break
            if isinstance(v, dict) and v.get("url"):
                mp4_url = v["url"]; break
    print(f"[seedance] DONE → {mp4_url}")
    return {"task_id": task_id, "asset_id": asset_id, "mp4_url": mp4_url, "raw": result}


if __name__ == "__main__":
    look_url = sys.argv[1]
    prompt = sys.argv[2] if len(sys.argv) > 2 else "Cinematic camera move."
    result = make_hook_from_look(look_url, prompt)
    print(json.dumps(result, indent=2))
