"""Persistent ARK asset-ID cache.

Once an ARK asset is Active, its asset_id is reusable indefinitely. The slow part of
registration is the server-side fetch + transcode + content-moderation that runs before
Status=Active. Caching the asset_id per source URL lets repeat runs skip all of that:
just verify the cached asset is still Active (one fast GetAsset) and reuse it.

Usage:
    from common.ark_cache import get_or_register
    aid = get_or_register(url, "Image", ak, sk)   # or "Video"
"""
from __future__ import annotations
import json, time
from pathlib import Path
from common import seedance_hook as sh

CACHE = Path(__file__).resolve().parent.parent / "demo" / ".ark_asset_cache.json"


def _load() -> dict:
    try:
        return json.loads(CACHE.read_text())
    except Exception:
        return {}


def _save(d: dict) -> None:
    CACHE.parent.mkdir(parents=True, exist_ok=True)
    CACHE.write_text(json.dumps(d, indent=1))


def _is_active(asset_id: str, ak: str, sk: str) -> bool:
    try:
        st = sh._volc_call("GetAsset", {"Id": asset_id}, ak, sk).get("Result", {}).get("Status")
        return st == "Active"
    except Exception:
        return False


def get_or_register(url: str, asset_type: str, ak: str, sk: str, timeout_s: int = 900) -> str:
    """Return an Active ARK asset_id for url, reusing the cache when possible.

    asset_type: "Image" or "Video".
    """
    cache = _load()
    key = f"{asset_type}:{url}"
    cached = cache.get(key)
    if cached and _is_active(cached, ak, sk):
        print(f"[ark_cache] reuse {cached} for {url.split('/')[-1]}", flush=True)
        return cached

    # cache miss or stale -> register fresh
    gr = sh._volc_call("CreateAssetGroup",
                       {"Name": f"cache-{int(time.time())}", "Description": "ark_cache"}, ak, sk)
    gid = gr["Result"]["Id"]
    aid = sh._volc_call("CreateAsset",
                       {"GroupId": gid, "Source": "URL", "URL": url, "AssetType": asset_type}, ak, sk)["Result"]["Id"]
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        time.sleep(5)
        st = sh._volc_call("GetAsset", {"Id": aid}, ak, sk).get("Result", {}).get("Status")
        if st == "Active":
            cache[key] = aid
            _save(cache)
            print(f"[ark_cache] registered {aid} for {url.split('/')[-1]}", flush=True)
            return aid
        if st in ("Failed", "Rejected"):
            raise RuntimeError(f"asset {aid} {st}")
    raise TimeoutError(f"asset {aid} not Active in {timeout_s}s")
