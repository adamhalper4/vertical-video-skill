# HeyGen Seedance Skills — Start Here

> **For the teammate's Claude agent:** read this file first. It tells you what's in this
> bundle, how to install it, and the *one* thing that blocks it from running (credentials).
> When the user asks you to "set this up" or "run the image-n eval / multi-camera pipeline",
> follow the **Setup** and **Credentials** sections below, then open the relevant skill's
> `SKILL.md` for the method.

## What this is

Three Claude Code skills that drive **Seedance 2.0** (BytePlus/Volcengine ARK) for HeyGen
avatar work. All three call ARK **directly** (not through the internal `Seedance2Workflow`
wrapper) — they're self-contained scripts you run locally.

| Skill | What it does | Use when |
|---|---|---|
| **av-image-n-looks** | Core Seedance primitive — generate identity-locked avatar *looks* as frames of a Seedance video (twin video ref + per-scene prompt → ArcFace-scored frame pick). The other two skills import from it. | "generate a look", "image-n look" |
| **av-image-n-eval** | Controlled eval harness over Image-N input configs (video/photo reference combos × fixed scenes), with anti-circularity ArcFace scoring + Gemini visual gate + resumable driver. | "eval image-n inputs", "does a photo rescue a bad video" |
| **av-multi-angle-video** | One look + a script → finished multi-camera talking-head with intent-driven angle cuts (camera-orbit side angles, masking close-ups, Whisper-timed cut sheet). | "multi-angle video", "multi-cam" |

## Setup (install into Claude Code)

Unzip and drop **all three folders** into your Claude Code skills directory:

```bash
unzip heygen-seedance-skills.zip
cp -R heygen-seedance-skills/av-* ~/.claude/skills/
```

They must live side by side — `av-multi-angle-video` imports `av-image-n-looks` by looking
for it at `~/.claude/skills/av-image-n-looks`. After copying, they're available as
`/av-image-n-looks`, `/av-image-n-eval`, `/av-multi-angle-video` (and auto-invoke on the
phrases above).

## Credentials — the only real gate

None of this runs without HeyGen's ARK/Volcengine credentials. **Seedance is internal —
there is no public / bring-your-own-key path.** You need access to HeyGen's Infisical
project `/heygen-server` (env `dev`); ask your manager / the avatar team if you don't have it.

| Env var | Purpose |
|---|---|
| `ARK_API_KEY` | ARK bearer token (Seedance generation endpoint) |
| `VOLC_ACCESSKEY` | Volcengine access key (asset registration / signing) |
| `VOLC_SECRETKEY` | Volcengine secret key (signing) |
| `SEEDANCE_AES_KEY` | computes the per-user `safety_identifier` moderation token |
| `GEMINI_API_KEY` | visual gate (artifacts / facial-hair / stray-text) + cut planning |
| HeyGen render access | HeyGen MCP **or** `HEYGEN_API_KEY` — for photo-avatar creation + camera renders (multi-angle only) |

The skills are written to pull these via Infisical at run time, e.g.:

```bash
infisical run --projectId=bdf5f4fb-ec02-4726-8ccd-acabaf7fa86f --env=dev --path=/heygen-server -- \
  uv run --python 3.11 \
    --with insightface --with onnxruntime --with numpy --with pillow \
    --with google-genai --with httpx --with pycryptodome -- \
    python <driver.py>
```

> **Quick check before a long run:** `echo "$ARK_API_KEY" | head -c 4` (inside the `infisical run`)
> — empty means you don't have the credential path provisioned yet. Fix that first.

## Python / system deps

- **Python 3.11** (not 3.14 — `onnxruntime`, used by ArcFace scoring, has no 3.14 wheels).
  Easiest is `uv run --python 3.11 --with ...` as shown above; per-skill `requirements.txt`
  lists the pins.
- **ffmpeg + ffprobe** on PATH (multi-angle assembly only).

## The three ARK gates (so a failed call makes sense)

Every Seedance request must clear these — the skills handle them, but know them:

1. **Min 409,600 px** on reference videos (640×480 fails — use 720p+); aspect ∈ [0.4, 2.5], duration ∈ [1.8s, 15.2s].
2. **Real-person videos via a raw URL are rejected** (`PrivacyInformation`). Register the
   media as an ARK asset first, then pass `asset://<id>`. (The skills cache asset IDs so the
   same twin video isn't re-ingested every run.)
3. **`safety_identifier` required** — AES-GCM of the username with `SEEDANCE_AES_KEY`.

## Where to go next

- Generating looks → open `av-image-n-looks/SKILL.md`
- Running an input eval → open `av-image-n-eval/SKILL.md` (+ `INSTALL.md`)
- Multi-camera video → open `av-multi-angle-video/SKILL.md` (+ `INSTALL.md`)
