---
name: av_auto_employee_training_ld
description: Generates an Automotive Employee Training & L&D video. Triggers on: automotive dealership employee training, L&D module, fleet HR onboarding, dealership SOP/process training, internal LMS course (Adelye / Hanna Imports / Grand Island Express pattern). Modal pattern: landscape 16:9, 371s, 10 scenes, alternating avatar_v ↔ motion_graphics. Anchored to the Stage H bucket-skill derived from Employee Training & L&D.
---

# Automotive — Employee Training & L&D

## What this skill does

Generates a `employee-training-ld` video using the Course Creator system-prompt pattern,
anchored to the Stage H bucket-skill output of the Automotive Vertical
Power-User Deep-Dive. The canonical recipe (this file's "Canonical recipe"
section), the input contract (`manifest.yaml`), the anchor catalogue
(`exemplars.json`), and the three persona looks (`looks/look_{1,2,3}.png`)
together form the reusable skill primitive.

**Role:** L&D parent template
**Goal:** Train dealership / fleet employees on process, SOP, or behavior change in a long-form internal LMS module
**Success metric:** Internal completion rate, post-module assessment pass-rate, repeat-view density

Modal pattern from Phase 2 consensus (n=9): landscape 16:9, 371s, 10-scene template.

## How to use

When the user invokes `/av_auto_employee_training_ld`, walk them through:

### 1. Gather inputs

Required:
- `avatar_id` — HeyGen avatar look_id (digital twin or Avatar V)
- `source_or_topic` — either a source URL (SOP doc, OEM bulletin, internal LMS link)
  OR a topic string (e.g. "objection handling — trade value", "DOT pre-trip inspection")

Optional:
- `language` — `en` / `es` / `pt` / `de` (multilingual variant defaults to `pt` per primary anchor)
- `brand_palette_overrides` — JSON with `{primary_hex, secondary_hex, font}`
- `custom_script` — pre-written script (skips auto-script-generation)
- `duration_sec` — default 371, alts [120, 240, 600]
- `orientation` — default `landscape`
- `cta` — call to action line

### 2. Pick a persona look

Show the user the 3 looks in `looks/` and let them pick one. Defaults to look_1.

### 3. Compose the prompt

Use the canonical recipe (below) verbatim with `[TOKEN]` substitutions filled
from steps 1 + 2. Honor the per-scene personality routing policy
(`personality_default`: 'on for talking-head A-roll scenes (no overlay); off for motion-graphics overlay scenes').

### 4. Dispatch via Video Agent

Call `mcp__claude_ai_HeyGen__create_video_agent` with:
- `prompt`: the composed system prompt
- `avatarId`: the user's chosen `look_id`
- `orientation`: from manifest defaults
- `mode`: `chat` (recommended — lets you confirm the parsed topic / SOP facts before final render)

Surface the session URL to the user: `https://app.heygen.com/video-agent/{session_id}`.

### 5. Poll until complete

Poll `mcp__claude_ai_HeyGen__get_video_agent_session` every ~45s until status
is `completed`. Fetch final video URL via `mcp__claude_ai_HeyGen__get_video`.

## Per-scene personality routing

Per `phase2_disposition_update.json:personality_default_per_bucket`:

> on for talking-head A-roll scenes (no overlay); off for motion-graphics overlay scenes

Concretely: on talking-head scenes flagged by the recipe as A-roll (no overlay,
`full_screen_avatar` layout), invoke the `custom-motion-expression` skill to
add per-scene audio tags + custom-motion presets. Skip personality routing on
motion-graphics-only scenes or scenes carrying burned-in captions / overlays.

## What NOT to do

- Internal-only tone — assume the viewer is an employee, not a customer.
- Avoid customer-acquisition language ('book a test drive', 'shop with us').
- Cite the SOP, dealer-group, or compliance source if one exists (lower-left small text).
- Don't render without showing the user the chosen persona look.
- Don't strip the source / SOP citation lines from the prompt (they're load-bearing).
- Don't drift the consensus model/layout pattern (Phase 2 evidence is the convergence target).

## Provenance

Stage H output of the Vertical Power-User Deep-Dive for the **Automotive** vertical
(2026-05-28). Canonical recipe reverse-engineered from Adelye Ltd +
6 primary anchors. See `exemplars.json`
for the full anchor list + `manifest.yaml` for inputs / outputs / API params.

---

## Canonical scene structure (Phase 2 consensus, n=9)

| # | Model | Layout | Modal Duration (s) | Overlay |
|---|---|---|---|---|
| 1 | `avatar_v` (89%) | `full_screen_avatar` (89%) | 11.9 | no |
| 2 | `motion_graphics` (62%) | `full_screen_motion_graphics` (50%) | 14.8 | yes |
| 3 | `avatar_v` (62%) | `full_screen_motion_graphics` (38%) | 11.8 | yes |
| 4 | `avatar_v` (62%) | `full_screen_avatar` (38%) | 14.9 | yes |
| 5 | `avatar_v` (62%) | `full_screen_motion_graphics` (38%) | 12.6 | yes |
| 6 | `avatar_v` (57%) | `full_screen_motion_graphics` (29%) | 8.5 | yes |
| 7 | `avatar_v` (100%) | `full_screen_avatar` (50%) | 12.4 | no |
| 8 | `motion_graphics` (50%) | `avatar_pip_over_broll` (50%) | 10.7 | yes |
| 9 | `avatar_v` (67%) | `full_screen_motion_graphics` (33%) | 13.1 | yes |
| 10 | `avatar_v` (67%) | `full_screen_avatar` (50%) | 9.0 | yes |

### Branding + format signature

- **Logo:** absent (85% consensus), position `br`
- **Font family:** `sans-serif` (78% consensus)
- **Aspect ratio:** `16:9` (67% consensus)
- **Captions burned-in:** `False` (67% consensus)
- **Music:** absent — style `uplifting_corp` (75%)
- **Total duration (modal):** 371s (range 81–617s)
- **Scene count (modal):** 10 (range 1–39, median 15)

### Acceptable variants

[
  {
    "variant": "scene_count_range",
    "min": 1,
    "max": 39,
    "median": 15
  },
  {
    "variant": "duration_range",
    "min_s": 81.0,
    "max_s": 617.0,
    "median_s": 371.2,
    "interpretation": "bucket spans short-form (<120s) AND long-form (>5min)"
  },
  {
    "variant": "aspect_ratio_bimodal",
    "distribution": {
      "9:16": 3,
      "16:9": 6
    }
  }
]

### Deviation warnings

- aspect_ratio not unanimous (16:9 only 66.7%)
- captions_burned_in not unanimous (False only 66.7%)

---

## Persona looks

### Look 1 — Hanna Imports — Dealership Sales Manager Office
- **Anchor:** Hanna Imports / Isaac Ward GSM
- **Persona:** hannaimports.com — Raleigh NC mid-market dealer training, GSM tone
- **ArcFace identity score:** 0.8915
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a navy blazer over an open-collar light blue dress shirt, standing in a modern dealership manager office with a wood desk, framed sales-team photos on the wall, and a large window with soft natural daylight behind him, eye-level professional headshot framing, calm authoritative GSM presence, looking at camera, mouth closed`
- **Asset:** `looks/look_1.png`

### Look 2 — Adelye / GI Express — Corporate Training Studio
- **Anchor:** Adelye Ltd (UK supply-chain L&D) + Grand Island Express
- **Persona:** adelye.com / giexpress.com — corporate training agency / fleet HR
- **ArcFace identity score:** 0.8785
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a charcoal-grey crew-neck sweater over a collared white shirt, standing in a clean corporate training room with a faint whiteboard and a tidy modular bookshelf softly out of focus, neutral grey-blue wall, even balanced studio key light, eye-level professional L&D-instructor framing, calm grounded teaching presence, looking at camera, mouth closed`
- **Asset:** `looks/look_2.png`

### Look 3 — Internal L&D Long-Form Masterclass
- **Anchor:** WBG Training Academy Masterclass pattern (Hanna Imports long-form)
- **Persona:** hannaimports.com — long-form executive training module
- **ArcFace identity score:** 0.8973
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a dark navy button-down shirt sleeves rolled to mid-forearm, standing in a corporate masterclass studio with a dark neutral backdrop and a soft cinematic key spotlight, slight rim light from camera right, eye-level executive-coach framing, calm authoritative module-host presence, looking at camera, mouth closed`
- **Asset:** `looks/look_3.png`


---

## Canonical recipe (Course Creator system prompt)

```
This is a [DURATION]-second Automotive — Employee Training & L&D video on the topic "[TOPIC_LABEL]".
The presenting persona is [PRESENTER_NAME], [PRESENTER_TITLE] at [ORG]. Target
audience: [AUDIENCE]. Voice and avatar: [AVATAR_TONE_HINT]. Language: [LANGUAGE].
Orientation: [ORIENTATION]. Aspect ratio: 16:9.

═══ CONTENT-TYPE GUARDRAIL ═══

Train dealership / fleet employees on process, SOP, or behavior change in a long-form internal LMS module. Bucket-role: L&D parent template. Convergence target: the
Phase 2 modal scene sequence below — do not drift to a different bucket's
template.

═══ SCENE STRUCTURE — TOTAL ≈371s, 10 SCENES ═══

Scene 1 (~11.9s): model=avatar_v · layout=full_screen_avatar · overlay=no
Scene 2 (~14.8s): model=motion_graphics · layout=full_screen_motion_graphics · overlay=yes
Scene 3 (~11.8s): model=avatar_v · layout=full_screen_motion_graphics · overlay=yes
Scene 4 (~14.9s): model=avatar_v · layout=full_screen_avatar · overlay=yes
Scene 5 (~12.6s): model=avatar_v · layout=full_screen_motion_graphics · overlay=yes
Scene 6 (~8.5s): model=avatar_v · layout=full_screen_motion_graphics · overlay=yes
Scene 7 (~12.4s): model=avatar_v · layout=full_screen_avatar · overlay=no
Scene 8 (~10.7s): model=motion_graphics · layout=avatar_pip_over_broll · overlay=yes
Scene 9 (~13.1s): model=avatar_v · layout=full_screen_motion_graphics · overlay=yes
Scene 10 (~9.0s): model=avatar_v · layout=full_screen_avatar · overlay=yes

═══ ON-SCREEN OVERLAYS ═══

- Burned-in captions optional / off by default (Phase 2: 66.7% no-captions).
- Lower-third with presenter name + title persists on every avatar scene.
- Logo placement: `br` (85% consensus).
- Font family: `sans-serif` (78% consensus). Substitute the user's brand font only if `brand_palette_overrides.font` is set.

═══ PERSONALITY ROUTING ═══

Per-scene personality routing default: on for talking-head A-roll scenes (no overlay); off for motion-graphics overlay scenes.
On qualifying A-roll scenes (talking-head, no overlay), pass the scene script
through the `custom-motion-expression` primitive to inject ElevenLabs V3
audio tags + a paired custom-motion preset before render. Skip on
motion-graphics / overlay-only scenes.

═══ ORIENTATION ═══

Default orientation: landscape. Landscape 16:9 is the modal pattern; portrait 9:16 is acceptable only if explicitly requested.

═══ LANGUAGE / VOICE ═══

Active language: [LANGUAGE]. Default English. Spanish / Portuguese supported on bilingual avatars. Per-language burned-in captions must be rendered in the target language.

═══ DO NOT INSERT ═══

- Pattern-interrupt openings (this bucket opens with the topic / question, not the presenter's name).
- Documentary archival footage (bucket-drift risk).
- Generic stock people footage outside the [PRESENTER]'s on-screen role.
- Music with vocals.
- Sub-2-second cuts (this bucket favors dwell on each scene).

═══ COMPLIANCE GUARDRAILS ═══

- Internal-only tone — assume the viewer is an employee, not a customer.
- Avoid customer-acquisition language ('book a test drive', 'shop with us').
- Cite the SOP, dealer-group, or compliance source if one exists (lower-left small text).

═══ EXEMPLAR ANCHORS ═══

The 10 anchors in `exemplars.json` are the convergence target. The top
6 `dedupe_role=primary` entries are the strongest signal. The remaining
entries are reference-only anchors from competitor / industry sources.

═══ END OF RECIPE ═══
```

## Convergence criteria

- Total duration within 81–617s
- Scene count within 1–39 (target 10)
- Aspect ratio: `16:9` (Phase 2 consensus 67%)
- Scene-1 model = `avatar_v` and scene-2 model = `motion_graphics` (Phase 2 modal opening)
- Captions optional/off (per consensus)
- Branding placement matches signature above

## v1 changelog

- v1 — initial Stage H Phase 4 output for Automotive vertical (2026-05-28). Reverse-engineered from Phase 2 consensus template (n=9) + 3 Phase 3 looks (ArcFace all ≥ 0.55). Personality routing default per `phase2_disposition_update.json`.
