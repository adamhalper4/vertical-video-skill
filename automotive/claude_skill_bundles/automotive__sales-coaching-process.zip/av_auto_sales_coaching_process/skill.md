---
name: av_auto_sales_coaching_process
description: Generates an Automotive Sales Coaching & Process Training (wedge) video. Triggers on: automotive sales coaching reel, dealership objection handling, sales-process training short, F&I or BDC creator-economy social, 9:16 dealer coach (Isaac Ward / Jain Morris pattern) — the ONLY social-native bucket in Automotive. Modal pattern: portrait 9:16, 75s, 7 scenes, alternating avatar_v ↔ motion_graphics. Anchored to the Stage H bucket-skill derived from Sales Coaching & Process Training.
---

# Automotive — Sales Coaching & Process Training (wedge)

## What this skill does

Generates a `sales-coaching-process` video using the Course Creator system-prompt pattern,
anchored to the Stage H bucket-skill output of the Automotive Vertical
Power-User Deep-Dive. The canonical recipe (this file's "Canonical recipe"
section), the input contract (`manifest.yaml`), the anchor catalogue
(`exemplars.json`), and the three persona looks (`looks/look_{1,2,3}.png`)
together form the reusable skill primitive.

**Role:** 🎯 WEDGE BUCKET — only social-native pattern in Automotive
**Goal:** Coach dealership / sales reps on one objection or process step in a 60–90s social reel; double-purpose as a creator-operator follower magnet
**Success metric:** Save+share rate, comment density, follower DM volume

Modal pattern from Phase 2 consensus (n=4): portrait 9:16, 75s, 7-scene template.

## How to use

When the user invokes `/av_auto_sales_coaching_process`, walk them through:

### 1. Gather inputs

Required:
- `avatar_id` — HeyGen avatar look_id (digital twin or Avatar V)
- `source_or_topic` — either a source URL (SOP doc, OEM bulletin, internal LMS link)
  OR a topic string (e.g. "objection handling — trade value", "DOT pre-trip inspection")

Optional:
- `language` — `en` / `es` / `pt` / `de` (multilingual variant defaults to `pt` per primary anchor)
- `brand_palette_overrides` — JSON with `{primary_hex, secondary_hex, font}`
- `custom_script` — pre-written script (skips auto-script-generation)
- `duration_sec` — default 75, alts [45, 90, 120]
- `orientation` — default `portrait`
- `cta` — call to action line

### 2. Pick a persona look

Show the user the 3 looks in `looks/` and let them pick one. Defaults to look_1.

### 3. Compose the prompt

Use the canonical recipe (below) verbatim with `[TOKEN]` substitutions filled
from steps 1 + 2. Honor the per-scene personality routing policy
(`personality_default`: 'on for talking-head scenes; off for captioned/overlay scenes (most of bucket due to burned-in captions)').

### 4. Dispatch via Video Agent

Call `mcp__claude_ai_HeyGen__create_video_agent` with:
- `prompt`: the composed system prompt
- `avatarId`: the user's chosen `look_id`
- `orientation`: from manifest defaults
- `mode`: `chat` (recommended — lets you confirm the parsed topic / SOP facts before final render)

Surface the session URL to the user: `https://app.heygen.com/video-agent/{session_id}`.

### 5. Poll until complete

Poll `mcp__claude_ai_HeyGen__get_video_agent_session` every ~45s until status
is `completed`. Fetch final video URL via `mcp__claude_ai_HeyGen__get_video`.

## Per-scene personality routing

Per `phase2_disposition_update.json:personality_default_per_bucket`:

> on for talking-head scenes; off for captioned/overlay scenes (most of bucket due to burned-in captions)

Concretely: on talking-head scenes flagged by the recipe as A-roll (no overlay,
`full_screen_avatar` layout), invoke the `custom-motion-expression` skill to
add per-scene audio tags + custom-motion presets. Skip personality routing on
motion-graphics-only scenes or scenes carrying burned-in captions / overlays.

## What NOT to do

- Burned-in captions are required — most viewers watch muted on socials.
- Open with the objection / problem as a question — never with the coach's name.
- One coaching point per video. If you need three points, ship three videos.
- Don't render without showing the user the chosen persona look.
- Don't strip the source / SOP citation lines from the prompt (they're load-bearing).
- Don't drift the consensus model/layout pattern (Phase 2 evidence is the convergence target).

## Provenance

Stage H output of the Vertical Power-User Deep-Dive for the **Automotive** vertical
(2026-05-28). Canonical recipe reverse-engineered from Isaac Ward +
2 primary anchors. See `exemplars.json`
for the full anchor list + `manifest.yaml` for inputs / outputs / API params.

---

## Canonical scene structure (Phase 2 consensus, n=4)

| # | Model | Layout | Modal Duration (s) | Overlay |
|---|---|---|---|---|
| 1 | `avatar_v` (50%) | `full_screen_avatar` (50%) | 15.5 | no |
| 2 | `motion_graphics` (100%) | `full_screen_motion_graphics` (100%) | 14.0 | yes |
| 3 | `motion_graphics` (67%) | `full_screen_motion_graphics` (67%) | 11.0 | yes |
| 4 | `motion_graphics` (67%) | `full_screen_motion_graphics` (67%) | 12.0 | yes |
| 5 | `avatar_v` (67%) | `full_screen_avatar` (33%) | 9.0 | yes |
| 6 | `motion_graphics` (100%) | `full_screen_motion_graphics` (100%) | 18.8 | yes |
| 7 | `motion_graphics` (50%) | `full_screen_motion_graphics` (50%) | 20.6 | yes |

### Branding + format signature

- **Logo:** present (72% consensus), position `tr`
- **Font family:** `sans-serif` (86% consensus)
- **Aspect ratio:** `9:16` (75% consensus)
- **Captions burned-in:** `True` (75% consensus)
- **Music:** present — style `uplifting_corp` (67%)
- **Total duration (modal):** 75s (range 56–476s)
- **Scene count (modal):** 7 (range 1–14, median 7)

### Acceptable variants

[
  {
    "variant": "scene_count_range",
    "min": 1,
    "max": 14,
    "median": 7
  },
  {
    "variant": "duration_range",
    "min_s": 56.0,
    "max_s": 476.0,
    "median_s": 75.0,
    "interpretation": "bucket spans short-form (<120s) AND long-form (>5min)"
  }
]

### Deviation warnings

_(none)_

---

## Persona looks

### Look 1 — Showroom Floor — Objection Handling Coach (9:16 tight)
- **Anchor:** Isaac Ward objection-handling style (Hanna Imports)
- **Persona:** hannaimports.com — Isaac Ward GSM, social-native objection handling reels
- **ArcFace identity score:** 0.8907
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a slim-fit charcoal polo, tight portrait headshot framing in a modern car dealership showroom, a sleek SUV softly out of focus behind one shoulder, polished floor and warm showroom downlights, head-and-shoulders-only composition leaving clean upper headroom and lower-third space, confident sales-mentor expression, looking directly at camera, mouth closed`
- **Asset:** `looks/look_1.png`

### Look 2 — Creator-Operator Sales Coach (9:16 portrait, vlog-ready)
- **Anchor:** Jain Morris creator-economy / dealer coach social
- **Persona:** user_57fdaf9a — Dealer Profit Secrets Exposed creator-economy sales coach
- **ArcFace identity score:** 0.8839
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a fitted black crewneck tee, tight portrait headshot framing against a clean blurred dealership lobby background with a hint of branded signage, ring-light style soft key with warm tone, head-and-shoulders-only composition with clear lower-third caption space, charismatic engaging mentor expression, looking directly at camera, mouth closed`
- **Asset:** `looks/look_2.png`

### Look 3 — Process Trainer at Whiteboard (9:16 portrait)
- **Anchor:** Process-training sub-pattern (sales-process coaching)
- **Persona:** Generic sales-process coach — direct-to-camera reel format
- **ArcFace identity score:** 0.8606
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a heather-grey quarter-zip pullover, tight portrait headshot framing in front of a slightly out-of-focus whiteboard with faint marker outlines, neutral warm overhead light, head-and-shoulders-only composition with clear lower-third caption space, friendly approachable coach expression, looking directly at camera, mouth closed`
- **Asset:** `looks/look_3.png`


---

## Canonical recipe (Course Creator system prompt)

```
This is a [DURATION]-second Automotive — Sales Coaching & Process Training (wedge) video on the topic "[TOPIC_LABEL]".
The presenting persona is [PRESENTER_NAME], [PRESENTER_TITLE] at [ORG]. Target
audience: [AUDIENCE]. Voice and avatar: [AVATAR_TONE_HINT]. Language: [LANGUAGE].
Orientation: [ORIENTATION]. Aspect ratio: 9:16.

═══ CONTENT-TYPE GUARDRAIL ═══

Coach dealership / sales reps on one objection or process step in a 60–90s social reel; double-purpose as a creator-operator follower magnet. Bucket-role: 🎯 WEDGE BUCKET — only social-native pattern in Automotive. Convergence target: the
Phase 2 modal scene sequence below — do not drift to a different bucket's
template.

═══ SCENE STRUCTURE — TOTAL ≈75s, 7 SCENES ═══

Scene 1 (~15.5s): model=avatar_v · layout=full_screen_avatar · overlay=no
Scene 2 (~14.0s): model=motion_graphics · layout=full_screen_motion_graphics · overlay=yes
Scene 3 (~11.0s): model=motion_graphics · layout=full_screen_motion_graphics · overlay=yes
Scene 4 (~12.0s): model=motion_graphics · layout=full_screen_motion_graphics · overlay=yes
Scene 5 (~9.0s): model=avatar_v · layout=full_screen_avatar · overlay=yes
Scene 6 (~18.8s): model=motion_graphics · layout=full_screen_motion_graphics · overlay=yes
Scene 7 (~20.6s): model=motion_graphics · layout=full_screen_motion_graphics · overlay=yes

═══ ON-SCREEN OVERLAYS ═══

- Burned-in per-scene captions are REQUIRED (Phase 2 consensus = 75.0% captions=True).
- Lower-third with presenter name + title persists on every avatar scene.
- Logo placement: `tr` (72% consensus).
- Font family: `sans-serif` (86% consensus). Substitute the user's brand font only if `brand_palette_overrides.font` is set.

═══ PERSONALITY ROUTING ═══

Per-scene personality routing default: on for talking-head scenes; off for captioned/overlay scenes (most of bucket due to burned-in captions).
On qualifying A-roll scenes (talking-head, no overlay), pass the scene script
through the `custom-motion-expression` primitive to inject ElevenLabs V3
audio tags + a paired custom-motion preset before render. Skip on
motion-graphics / overlay-only scenes.

═══ ORIENTATION ═══

Default orientation: portrait. Portrait 9:16 is non-negotiable for this bucket — it is the social-native wedge.

═══ LANGUAGE / VOICE ═══

Active language: [LANGUAGE]. Default English. Spanish / Portuguese supported on bilingual avatars. Per-language burned-in captions must be rendered in the target language.

═══ DO NOT INSERT ═══

- Pattern-interrupt openings (this bucket opens with the topic / question, not the presenter's name).
- Documentary archival footage (bucket-drift risk).
- Generic stock people footage outside the [PRESENTER]'s on-screen role.
- Music with vocals.
- Anything that prevents the social-reel feel — keep cuts tight, captions on screen, hook in first 2s.

═══ COMPLIANCE GUARDRAILS ═══

- Burned-in captions are required — most viewers watch muted on socials.
- Open with the objection / problem as a question — never with the coach's name.
- One coaching point per video. If you need three points, ship three videos.

═══ EXEMPLAR ANCHORS ═══

The 10 anchors in `exemplars.json` are the convergence target. The top
2 `dedupe_role=primary` entries are the strongest signal. The remaining
entries are reference-only anchors from competitor / industry sources.

═══ END OF RECIPE ═══
```

## Convergence criteria

- Total duration within 56–476s
- Scene count within 1–14 (target 7)
- Aspect ratio: `9:16` (Phase 2 consensus 75%)
- Scene-1 model = `avatar_v` and scene-2 model = `motion_graphics` (Phase 2 modal opening)
- Captions burned in (per consensus)
- Branding placement matches signature above

## v1 changelog

- v1 — initial Stage H Phase 4 output for Automotive vertical (2026-05-28). Reverse-engineered from Phase 2 consensus template (n=4) + 3 Phase 3 looks (ArcFace all ≥ 0.55). Personality routing default per `phase2_disposition_update.json`.
