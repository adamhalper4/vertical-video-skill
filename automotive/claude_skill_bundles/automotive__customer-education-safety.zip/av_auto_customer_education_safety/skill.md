---
name: av_auto_customer_education_safety
description: Generates an Automotive Customer Education & Safety video. Triggers on: automotive customer education explainer, vehicle safety walkthrough, brand-safe service-bay educator, fleet driver safety / DOT compliance (CarGroup Holdings / webuyanycar / Grand Island Express / Adelye pattern). Modal pattern: landscape 16:9, 278s, 10 scenes, alternating avatar_v ↔ motion_graphics. Anchored to the Stage H bucket-skill derived from Customer Education & Safety.
---

# Automotive — Customer Education & Safety

## What this skill does

Generates a `customer-education-safety` video using the Course Creator system-prompt pattern,
anchored to the Stage H bucket-skill output of the Automotive Vertical
Power-User Deep-Dive. The canonical recipe (this file's "Canonical recipe"
section), the input contract (`manifest.yaml`), the anchor catalogue
(`exemplars.json`), and the three persona looks (`looks/look_{1,2,3}.png`)
together form the reusable skill primitive.

**Role:** L&D sub-genre — customer-facing tone
**Goal:** Educate customers (or B2B drivers acting as customers) on a vehicle, safety, or service topic in a brand-safe, approachable register
**Success metric:** Customer-confidence lift, lower service-bay support calls, brand-trust signals

Modal pattern from Phase 2 consensus (n=3): landscape 16:9, 278s, 10-scene template.

## How to use

When the user invokes `/av_auto_customer_education_safety`, walk them through:

### 1. Gather inputs

Required:
- `avatar_id` — HeyGen avatar look_id (digital twin or Avatar V)
- `source_or_topic` — either a source URL (SOP doc, OEM bulletin, internal LMS link)
  OR a topic string (e.g. "objection handling — trade value", "DOT pre-trip inspection")

Optional:
- `language` — `en` / `es` / `pt` / `de` (multilingual variant defaults to `pt` per primary anchor)
- `brand_palette_overrides` — JSON with `{primary_hex, secondary_hex, font}`
- `custom_script` — pre-written script (skips auto-script-generation)
- `duration_sec` — default 278, alts [60, 120, 420]
- `orientation` — default `landscape`
- `cta` — call to action line

### 2. Pick a persona look

Show the user the 3 looks in `looks/` and let them pick one. Defaults to look_1.

### 3. Compose the prompt

Use the canonical recipe (below) verbatim with `[TOKEN]` substitutions filled
from steps 1 + 2. Honor the per-scene personality routing policy
(`personality_default`: 'on for talking-head A-roll (no overlay)').

### 4. Dispatch via Video Agent

Call `mcp__claude_ai_HeyGen__create_video_agent` with:
- `prompt`: the composed system prompt
- `avatarId`: the user's chosen `look_id`
- `orientation`: from manifest defaults
- `mode`: `chat` (recommended — lets you confirm the parsed topic / SOP facts before final render)

Surface the session URL to the user: `https://app.heygen.com/video-agent/{session_id}`.

### 5. Poll until complete

Poll `mcp__claude_ai_HeyGen__get_video_agent_session` every ~45s until status
is `completed`. Fetch final video URL via `mcp__claude_ai_HeyGen__get_video`.

## Per-scene personality routing

Per `phase2_disposition_update.json:personality_default_per_bucket`:

> on for talking-head A-roll (no overlay)

Concretely: on talking-head scenes flagged by the recipe as A-roll (no overlay,
`full_screen_avatar` layout), invoke the `custom-motion-expression` skill to
add per-scene audio tags + custom-motion presets. Skip personality routing on
motion-graphics-only scenes or scenes carrying burned-in captions / overlays.

## What NOT to do

- Customer-facing tone — warm, brand-aligned, never internal-jargon.
- Safety claims must be source-attributed (DOT / OEM bulletin / brand spec).
- No prescriptive 'you should buy X' — keep recommendations conditional and explanatory.
- Don't render without showing the user the chosen persona look.
- Don't strip the source / SOP citation lines from the prompt (they're load-bearing).
- Don't drift the consensus model/layout pattern (Phase 2 evidence is the convergence target).

## Provenance

Stage H output of the Vertical Power-User Deep-Dive for the **Automotive** vertical
(2026-05-28). Canonical recipe reverse-engineered from Adelye Ltd +
3 primary anchors. See `exemplars.json`
for the full anchor list + `manifest.yaml` for inputs / outputs / API params.

---

## Canonical scene structure (Phase 2 consensus, n=3)

| # | Model | Layout | Modal Duration (s) | Overlay |
|---|---|---|---|---|
| 1 | `avatar_v` (67%) | `full_screen_avatar` (100%) | 11.2 | no |
| 2 | `motion_graphics` (67%) | `full_screen_avatar` (33%) | 3.0 | yes |
| 3 | `avatar_v` (67%) | `full_screen_avatar` (67%) | 9.3 | no |
| 4 | `motion_graphics` (67%) | `full_screen_avatar` (33%) | 5.5 | yes |
| 5 | `avatar_v` (67%) | `full_screen_avatar` (67%) | 4.4 | no |
| 6 | `motion_graphics` (67%) | `full_screen_avatar` (33%) | 2.8 | yes |
| 7 | `avatar_v` (67%) | `full_screen_avatar` (67%) | 13.0 | no |
| 8 | `motion_graphics` (67%) | `full_screen_avatar` (33%) | 2.2 | yes |
| 9 | `avatar_iv` (50%) | `avatar_pip_over_broll` (50%) | 10.9 | yes |
| 10 | `motion_graphics` (100%) | `full_screen_motion_graphics` (50%) | 9.9 | yes |

### Branding + format signature

- **Logo:** absent (95% consensus), position `tl`
- **Font family:** `Arial` (81% consensus)
- **Aspect ratio:** `16:9` (67% consensus)
- **Captions burned-in:** `False` (100% consensus)
- **Music:** absent — style `None` (0%)
- **Total duration (modal):** 278s (range 32–423s)
- **Scene count (modal):** 10 (range 8–20, median 15)

### Acceptable variants

[
  {
    "variant": "scene_count_range",
    "min": 8,
    "max": 20,
    "median": 15
  },
  {
    "variant": "duration_range",
    "min_s": 32.4,
    "max_s": 423.0,
    "median_s": 278.0,
    "interpretation": "bucket spans short-form (<120s) AND long-form (>5min)"
  },
  {
    "variant": "aspect_ratio_bimodal",
    "distribution": {
      "9:16": 1,
      "16:9": 2
    }
  },
  {
    "variant": "avatar_iv_v_split",
    "avatar_iv_pct": 40.7,
    "avatar_v_pct": 59.3
  }
]

### Deviation warnings

- aspect_ratio not unanimous (16:9 only 66.7%)

---

## Persona looks

### Look 1 — CarGroup Holdings — Brand-Safe Customer Educator
- **Anchor:** CarGroup Holdings / webuyanycar.com (Marcus / Master The Minute)
- **Persona:** webuyanycar.com — customer-facing brand-safe educator, warm and approachable
- **ArcFace identity score:** 0.8519
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a smart-casual light-blue button-down shirt sleeves rolled to forearm, standing in a clean modern dealership welcome lobby with glass doors and a polished service counter softly out of focus behind him, warm welcoming daylight from a large window, eye-level customer-facing educator framing, friendly trustworthy expression, looking at camera, mouth closed`
- **Asset:** `looks/look_1.png`

### Look 2 — Driver Safety / DOT Compliance Educator
- **Anchor:** Grand Island Express / Lucas Mowrey trucking safety
- **Persona:** giexpress.com — fleet safety, DOT compliance, brand-safe trainer
- **ArcFace identity score:** 0.8969
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a navy button-down shirt with a high-visibility orange safety vest layered over it, standing in a fleet operations training room with a softly out-of-focus map and safety-policy posters behind him, bright even fluorescent overhead lighting, eye-level safety-manager framing, calm authoritative compliance-trainer expression, looking at camera, mouth closed`
- **Asset:** `looks/look_2.png`

### Look 3 — Customer Safety Walkthrough Host
- **Anchor:** Adelye behavioral-change customer safety pattern
- **Persona:** adelye.com — customer-facing safety / behavior change, warm brand-aligned host
- **ArcFace identity score:** 0.8840
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a warm taupe knit pullover over a collared shirt, standing in a clean automotive customer-service area with a vehicle in the bay softly out of focus behind him, warm soft daylight from camera left, eye-level approachable host framing, thoughtful warm educator expression, looking at camera, mouth closed`
- **Asset:** `looks/look_3.png`


---

## Canonical recipe (Course Creator system prompt)

```
This is a [DURATION]-second Automotive — Customer Education & Safety video on the topic "[TOPIC_LABEL]".
The presenting persona is [PRESENTER_NAME], [PRESENTER_TITLE] at [ORG]. Target
audience: [AUDIENCE]. Voice and avatar: [AVATAR_TONE_HINT]. Language: [LANGUAGE].
Orientation: [ORIENTATION]. Aspect ratio: 16:9.

═══ CONTENT-TYPE GUARDRAIL ═══

Educate customers (or B2B drivers acting as customers) on a vehicle, safety, or service topic in a brand-safe, approachable register. Bucket-role: L&D sub-genre — customer-facing tone. Convergence target: the
Phase 2 modal scene sequence below — do not drift to a different bucket's
template.

═══ SCENE STRUCTURE — TOTAL ≈278s, 10 SCENES ═══

Scene 1 (~11.2s): model=avatar_v · layout=full_screen_avatar · overlay=no
Scene 2 (~3.0s): model=motion_graphics · layout=full_screen_avatar · overlay=yes
Scene 3 (~9.3s): model=avatar_v · layout=full_screen_avatar · overlay=no
Scene 4 (~5.5s): model=motion_graphics · layout=full_screen_avatar · overlay=yes
Scene 5 (~4.4s): model=avatar_v · layout=full_screen_avatar · overlay=no
Scene 6 (~2.8s): model=motion_graphics · layout=full_screen_avatar · overlay=yes
Scene 7 (~13.0s): model=avatar_v · layout=full_screen_avatar · overlay=no
Scene 8 (~2.2s): model=motion_graphics · layout=full_screen_avatar · overlay=yes
Scene 9 (~10.9s): model=avatar_iv · layout=avatar_pip_over_broll · overlay=yes
Scene 10 (~9.9s): model=motion_graphics · layout=full_screen_motion_graphics · overlay=yes

═══ ON-SCREEN OVERLAYS ═══

- Burned-in captions optional / off by default (Phase 2: 100.0% no-captions).
- Lower-third with presenter name + title persists on every avatar scene.
- Logo placement: `tl` (95% consensus).
- Font family: `Arial` (81% consensus). Substitute the user's brand font only if `brand_palette_overrides.font` is set.

═══ PERSONALITY ROUTING ═══

Per-scene personality routing default: on for talking-head A-roll (no overlay).
On qualifying A-roll scenes (talking-head, no overlay), pass the scene script
through the `custom-motion-expression` primitive to inject ElevenLabs V3
audio tags + a paired custom-motion preset before render. Skip on
motion-graphics / overlay-only scenes.

═══ ORIENTATION ═══

Default orientation: landscape. Landscape 16:9 is the modal pattern; portrait 9:16 is acceptable only if explicitly requested.

═══ LANGUAGE / VOICE ═══

Active language: [LANGUAGE]. Default English. Spanish / Portuguese supported on bilingual avatars. Per-language burned-in captions must be rendered in the target language.

═══ DO NOT INSERT ═══

- Pattern-interrupt openings (this bucket opens with the topic / question, not the presenter's name).
- Documentary archival footage (bucket-drift risk).
- Generic stock people footage outside the [PRESENTER]'s on-screen role.
- Music with vocals.
- Sub-2-second cuts (this bucket favors dwell on each scene).

═══ COMPLIANCE GUARDRAILS ═══

- Customer-facing tone — warm, brand-aligned, never internal-jargon.
- Safety claims must be source-attributed (DOT / OEM bulletin / brand spec).
- No prescriptive 'you should buy X' — keep recommendations conditional and explanatory.

═══ EXEMPLAR ANCHORS ═══

The 10 anchors in `exemplars.json` are the convergence target. The top
3 `dedupe_role=primary` entries are the strongest signal. The remaining
entries are reference-only anchors from competitor / industry sources.

═══ END OF RECIPE ═══
```

## Convergence criteria

- Total duration within 32–423s
- Scene count within 8–20 (target 10)
- Aspect ratio: `16:9` (Phase 2 consensus 67%)
- Scene-1 model = `avatar_v` and scene-2 model = `motion_graphics` (Phase 2 modal opening)
- Captions optional/off (per consensus)
- Branding placement matches signature above

## v1 changelog

- v1 — initial Stage H Phase 4 output for Automotive vertical (2026-05-28). Reverse-engineered from Phase 2 consensus template (n=3) + 3 Phase 3 looks (ArcFace all ≥ 0.55). Personality routing default per `phase2_disposition_update.json`.
