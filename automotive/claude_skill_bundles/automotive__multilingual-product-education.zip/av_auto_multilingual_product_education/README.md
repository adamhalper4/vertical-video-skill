# `av_auto_multilingual_product_education` — Automotive bucket-skill

Stage H output of the **Automotive** Vertical Power-User Deep-Dive
(2026-05-28). Generates a `multilingual-product-education` video using the Course Creator
system-prompt pattern + 3 persona looks + 10 anchor exemplars.

## Install

### Claude Code (terminal)

```bash
mkdir -p ~/.claude/skills
unzip automotive__multilingual-product-education.zip -d ~/.claude/skills/
```

Restart Claude Code, then invoke in any session:

```
/av_auto_multilingual_product_education
```

### Claude.ai (web)

1. Settings → Capabilities → Skills
2. Click **Upload skill**
3. Upload this `.zip`
4. Skill becomes available across all conversations

### Claude API / Agent SDK

```python
from claude_agent_sdk import ClaudeAgentOptions
options = ClaudeAgentOptions(
    setting_sources=["project"],
    cwd="/path/to/folder/containing/av_auto_multilingual_product_education",
)
```

See https://docs.claude.com/en/api/agent-sdk/skills

## Invoke

Once installed:

```
/av_auto_multilingual_product_education
```

The skill will walk through:

1. Gather inputs (avatar_id + source_url-or-topic + optional language / brand overrides).
2. Show the 3 persona looks and let you pick one.
3. Compose the Course Creator prompt with your inputs substituted.
4. Dispatch via `create_video_agent` and surface the session URL.
5. Poll until the render completes; return the final video URL.

## Bundle contents

- `skill.md` — Claude Skill definition + canonical Course Creator recipe
- `manifest.yaml` — inputs / outputs / looks / defaults / API params
- `exemplars.json` — 10 anchor canonicals (primary + reference-only)
- `looks/look_{1,2,3}.png` — 3 Image-N + Seedance frame-picked persona looks
- `README.md` — this file

## Provenance

Built from:
- `phase1a_qualified_canonicals.json` (anchor catalogue)
- `phase2_consensus_templates.json` (modal scene sequence + branding)
- `phase3_looks/multilingual-product-education/` (3 ArcFace ≥ 0.55 persona looks)
- `phase2_disposition_update.json` (per-bucket personality routing policy)
