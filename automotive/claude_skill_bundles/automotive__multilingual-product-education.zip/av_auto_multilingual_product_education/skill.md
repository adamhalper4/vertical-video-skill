---
name: av_auto_multilingual_product_education
description: Generates an Automotive Multilingual Product Education (stock-scaffold variant) video. Triggers on: multilingual automotive product overview, stock-footage-scaffolded vehicle / parts / service explainer with translated voiceover, prompt-pack-driven multilingual auto content (Projetos Flow AI pattern). Modal pattern: landscape 16:9, 273s, 10 scenes, alternating stock_footage ↔ stock_footage. Anchored to the Stage H bucket-skill derived from Multilingual Product Education.
---

# Automotive — Multilingual Product Education (stock-scaffold variant)

## What this skill does

Generates a `multilingual-product-education` video using the Course Creator system-prompt pattern,
anchored to the Stage H bucket-skill output of the Automotive Vertical
Power-User Deep-Dive. The canonical recipe (this file's "Canonical recipe"
section), the input contract (`manifest.yaml`), the anchor catalogue
(`exemplars.json`), and the three persona looks (`looks/look_{1,2,3}.png`)
together form the reusable skill primitive.

**Role:** Stock-scaffold variant (NOT avatar-performance template)
**Goal:** Produce a multilingual product / model / service overview by translating one prompt-pack across N target languages and re-using a shared stock-footage scaffold; avatar is a brief cutaway, not the main canvas
**Success metric:** Cost-per-language reduction; per-language watch-through parity vs source-language baseline

Modal pattern from Phase 2 consensus (n=4): landscape 16:9, 273s, 10-scene template.

## How to use

When the user invokes `/av_auto_multilingual_product_education`, walk them through:

### 1. Gather inputs

Required:
- `avatar_id` — HeyGen avatar look_id (digital twin or Avatar V)
- `source_or_topic` — either a source URL (SOP doc, OEM bulletin, internal LMS link)
  OR a topic string (e.g. "objection handling — trade value", "DOT pre-trip inspection")

Optional:
- `language` — `en` / `es` / `pt` / `de` (multilingual variant defaults to `pt` per primary anchor)
- `brand_palette_overrides` — JSON with `{primary_hex, secondary_hex, font}`
- `custom_script` — pre-written script (skips auto-script-generation)
- `duration_sec` — default 273, alts [180, 360, 480]
- `orientation` — default `landscape`
- `cta` — call to action line

### 2. Pick a persona look

Show the user the 3 looks in `looks/` and let them pick one. Defaults to look_1.

### 3. Compose the prompt

Use the canonical recipe (below) verbatim with `[TOKEN]` substitutions filled
from steps 1 + 2. Honor the per-scene personality routing policy
(`personality_default`: 'on for the few avatar_v talking-head scenes; mostly N/A since bucket is stock-dominated').

### 4. Dispatch via Video Agent

Call `mcp__claude_ai_HeyGen__create_video_agent` with:
- `prompt`: the composed system prompt
- `avatarId`: the user's chosen `look_id`
- `orientation`: from manifest defaults
- `mode`: `chat` (recommended — lets you confirm the parsed topic / SOP facts before final render)

Surface the session URL to the user: `https://app.heygen.com/video-agent/{session_id}`.

### 5. Poll until complete

Poll `mcp__claude_ai_HeyGen__get_video_agent_session` every ~45s until status
is `completed`. Fetch final video URL via `mcp__claude_ai_HeyGen__get_video`.

## Per-scene personality routing

Per `phase2_disposition_update.json:personality_default_per_bucket`:

> on for the few avatar_v talking-head scenes; mostly N/A since bucket is stock-dominated

Concretely: on talking-head scenes flagged by the recipe as A-roll (no overlay,
`full_screen_avatar` layout), invoke the `custom-motion-expression` skill to
add per-scene audio tags + custom-motion presets. Skip personality routing on
motion-graphics-only scenes or scenes carrying burned-in captions / overlays.

## What NOT to do

- Stock-footage scaffold is load-bearing — 9 of 10 scenes are stock, only 1 is the avatar cutaway. Do NOT shift to a talking-head template.
- Per-language burned-in captions are required (this bucket's #1 ranking signal).
- Avatar cutaway must use a brand-neutral, language-neutral look — no localized branding signals.
- Translation pipeline: ship one base script, fan out to per-language renders sharing the stock scaffold.
- Don't render without showing the user the chosen persona look.
- Don't strip the source / SOP citation lines from the prompt (they're load-bearing).
- Don't drift the consensus model/layout pattern (Phase 2 evidence is the convergence target).

## Provenance

Stage H output of the Vertical Power-User Deep-Dive for the **Automotive** vertical
(2026-05-28). Canonical recipe reverse-engineered from Projetos Flow AI +
2 primary anchors. See `exemplars.json`
for the full anchor list + `manifest.yaml` for inputs / outputs / API params.

---

## Canonical scene structure (Phase 2 consensus, n=4)

| # | Model | Layout | Modal Duration (s) | Overlay |
|---|---|---|---|---|
| 1 | `stock_footage` (75%) | `full_screen_broll` (50%) | 7.3 | yes |
| 2 | `stock_footage` (50%) | `full_screen_broll` (75%) | 4.4 | yes |
| 3 | `stock_footage` (50%) | `full_screen_broll` (75%) | 5.2 | yes |
| 4 | `avatar_v` (50%) | `full_screen_avatar` (50%) | 9.1 | yes |
| 5 | `stock_footage` (75%) | `full_screen_broll` (75%) | 4.9 | yes |
| 6 | `stock_footage` (75%) | `full_screen_broll` (75%) | 5.0 | yes |
| 7 | `stock_footage` (75%) | `full_screen_broll` (75%) | 4.5 | yes |
| 8 | `stock_footage` (75%) | `full_screen_broll` (50%) | 8.1 | yes |
| 9 | `stock_footage` (50%) | `full_screen_broll` (75%) | 5.2 | yes |
| 10 | `stock_footage` (75%) | `full_screen_broll` (75%) | 5.9 | yes |

### Branding + format signature

- **Logo:** absent (100% consensus), position `n/a`
- **Font family:** `sans-serif` (100% consensus)
- **Aspect ratio:** `16:9` (100% consensus)
- **Captions burned-in:** `True` (100% consensus)
- **Music:** present — style `cinematic` (75%)
- **Total duration (modal):** 273s (range 186–521s)
- **Scene count (modal):** 10 (range 30–51, median 40)

### Acceptable variants

[
  {
    "variant": "scene_count_range",
    "min": 30,
    "max": 51,
    "median": 40
  }
]

### Deviation warnings

- long-form bucket: median scene_count=40 — consensus template trimmed to 10 positions for the skill template; full-length variant should sample widely

---

## Persona looks

### Look 1 — Global Brand-Neutral Talking-Head Insert
- **Anchor:** Projetos Flow AI multilingual stock-scaffold variant
- **Persona:** Projetos Flow AI — stock-scaffolded multilingual, neutral brand-safe presenter
- **ArcFace identity score:** 0.8798
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a clean neutral charcoal-grey crewneck top, standing centered against a soft seamless light-grey studio backdrop, even flat studio lighting from both sides with no shadows, eye-level clean cutaway-insert framing with generous negative space on both sides for stock-footage transitions, neutral globally-recognizable professional presenter expression, looking at camera, mouth closed`
- **Asset:** `looks/look_1.png`

### Look 2 — Product Education Cutaway Host
- **Anchor:** Multilingual product-education intro talking-head
- **Persona:** Projetos Flow AI — product-overview intro cutaway
- **ArcFace identity score:** 0.8992
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a clean navy blazer over a plain white tee, standing against a softly blurred modern showroom background with neutral wall tones, even soft daylight key, eye-level neutral-host framing with clear surrounding space for graphic overlays, calm informative brand-neutral expression, looking at camera, mouth closed`
- **Asset:** `looks/look_2.png`

### Look 3 — Translation-Pack Narrator Cutaway
- **Anchor:** Stock-scaffolded multilingual narration cutaway
- **Persona:** Projetos Flow AI — narrator-style intro between stock b-roll
- **ArcFace identity score:** 0.8927
- **Prompt (Image-N + Seedance frame-pick):** `a clean-shaven man in his 30s wearing a clean dark teal collared shirt buttoned at top, standing against a soft warm-grey neutral backdrop with a hint of architectural softness, balanced soft three-point lighting, eye-level narrator-style framing with clear text-overlay safe space around shoulders, calm globally-neutral narrator expression, looking at camera, mouth closed`
- **Asset:** `looks/look_3.png`


---

## Canonical recipe (Course Creator system prompt)

```
This is a [DURATION]-second Automotive — Multilingual Product Education (stock-scaffold variant) video on the topic "[TOPIC_LABEL]".
The presenting persona is [PRESENTER_NAME], [PRESENTER_TITLE] at [ORG]. Target
audience: [AUDIENCE]. Voice and avatar: [AVATAR_TONE_HINT]. Language: [LANGUAGE].
Orientation: [ORIENTATION]. Aspect ratio: 16:9.

═══ CONTENT-TYPE GUARDRAIL ═══

Produce a multilingual product / model / service overview by translating one prompt-pack across N target languages and re-using a shared stock-footage scaffold; avatar is a brief cutaway, not the main canvas. Bucket-role: Stock-scaffold variant (NOT avatar-performance template). Convergence target: the
Phase 2 modal scene sequence below — do not drift to a different bucket's
template.

═══ SCENE STRUCTURE — TOTAL ≈273s, 10 SCENES ═══

Scene 1 (~7.3s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 2 (~4.4s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 3 (~5.2s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 4 (~9.1s): model=avatar_v · layout=full_screen_avatar · overlay=yes
Scene 5 (~4.9s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 6 (~5.0s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 7 (~4.5s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 8 (~8.1s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 9 (~5.2s): model=stock_footage · layout=full_screen_broll · overlay=yes
Scene 10 (~5.9s): model=stock_footage · layout=full_screen_broll · overlay=yes

═══ ON-SCREEN OVERLAYS ═══

- Burned-in per-scene captions are REQUIRED (Phase 2 consensus = 100.0% captions=True).
- Lower-third with presenter name + title persists on every avatar scene.
- Logo placement: `no logo` (100% consensus).
- Font family: `sans-serif` (100% consensus). Substitute the user's brand font only if `brand_palette_overrides.font` is set.

═══ PERSONALITY ROUTING ═══

Per-scene personality routing default: on for the few avatar_v talking-head scenes; mostly N/A since bucket is stock-dominated.
On qualifying A-roll scenes (talking-head, no overlay), pass the scene script
through the `custom-motion-expression` primitive to inject ElevenLabs V3
audio tags + a paired custom-motion preset before render. Skip on
motion-graphics / overlay-only scenes.

═══ ORIENTATION ═══

Default orientation: landscape. Landscape 16:9 is the modal pattern; portrait 9:16 is acceptable only if explicitly requested.

═══ LANGUAGE / VOICE ═══

Active language: [LANGUAGE]. Multilingual variant — fan out one base script to N target languages and re-use the same stock scaffold. Per-language burned-in captions must be rendered in the target language.

═══ DO NOT INSERT ═══

- Pattern-interrupt openings (this bucket opens with the topic / question, not the presenter's name).
- Documentary archival footage (bucket-drift risk).
- Generic stock people footage outside the [PRESENTER]'s on-screen role.
- Music with vocals.
- Sub-2-second cuts (this bucket favors dwell on each scene).

═══ COMPLIANCE GUARDRAILS ═══

- Stock-footage scaffold is load-bearing — 9 of 10 scenes are stock, only 1 is the avatar cutaway. Do NOT shift to a talking-head template.
- Per-language burned-in captions are required (this bucket's #1 ranking signal).
- Avatar cutaway must use a brand-neutral, language-neutral look — no localized branding signals.
- Translation pipeline: ship one base script, fan out to per-language renders sharing the stock scaffold.

═══ EXEMPLAR ANCHORS ═══

The 10 anchors in `exemplars.json` are the convergence target. The top
2 `dedupe_role=primary` entries are the strongest signal. The remaining
entries are reference-only anchors from competitor / industry sources.

═══ END OF RECIPE ═══
```

## Convergence criteria

- Total duration within 186–521s
- Scene count within 30–51 (target 10)
- Aspect ratio: `16:9` (Phase 2 consensus 100%)
- Scene-1 model = `stock_footage` and scene-2 model = `stock_footage` (Phase 2 modal opening)
- Captions burned in (per consensus)
- Branding placement matches signature above

## v1 changelog

- v1 — initial Stage H Phase 4 output for Automotive vertical (2026-05-28). Reverse-engineered from Phase 2 consensus template (n=4) + 3 Phase 3 looks (ArcFace all ≥ 0.55). Personality routing default per `phase2_disposition_update.json`.
